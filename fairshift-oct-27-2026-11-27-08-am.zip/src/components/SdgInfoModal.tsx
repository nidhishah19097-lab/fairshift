import React from 'react';
import { X, ShieldCheck, HeartHandshake, HardHat, School, Check, Scale } from 'lucide-react';
import { Language } from '../types';

interface SdgInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const SdgInfoModal: React.FC<SdgInfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="sdg-modal-title"
    >
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-rose-600 flex items-center justify-center text-white font-black text-lg shadow-sm">
              8
            </div>
            <div>
              <h2 id="sdg-modal-title" className="text-lg font-bold text-slate-900 leading-tight">
                UN SDG 8: Decent Work & Economic Growth
              </h2>
              <p className="text-xs text-slate-500">
                FairShift Alignment for Prompt Wars 2026 (SRM ACM Chapter)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors focus:ring-2 focus:ring-blue-500"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 text-sm text-slate-700 leading-relaxed">
          {/* Mission statement */}
          <div className="bg-blue-50/70 border border-blue-200/80 rounded-xl p-4">
            <h3 className="font-semibold text-blue-950 flex items-center gap-2 mb-1">
              <Scale className="w-4 h-4 text-blue-700" />
              Core Principle: Work Should Be Fair
            </h3>
            <p className="text-blue-900/90 text-xs sm:text-sm">
              Across emerging economies and campus ecosystems, contract workers frequently suffer from
              unrecorded overtime, opaque pay deduction slips, and hazardous site conditions they fear
              reporting due to reprisal risks. FairShift bridges the trust gap through timestamped
              immutable shift logs, transparent wage estimation, and anonymous SafeVoice reporting.
            </p>
          </div>

          {/* SDG Targets */}
          <div>
            <h4 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Direct Target Alignments
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50">
                <div className="font-semibold text-slate-900 text-xs mb-1">Target 8.8: Safe Work Environments</div>
                <p className="text-xs text-slate-600">
                  Protect labour rights and promote safe working environments for all workers, especially
                  precarious construction and facility staff through anonymous SafeVoice hazard escalation and FatigueGuard rest enforcement.
                </p>
              </div>
              <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50">
                <div className="font-semibold text-slate-900 text-xs mb-1">Target 8.5: Decent Work & Fair Pay</div>
                <p className="text-xs text-slate-600">
                  Achieve productive employment and decent work with transparent statutory calculation of
                  overtime multiplier pay (1.5x / 2.0x) eliminating wage theft and opaque deductions.
                </p>
              </div>
            </div>
          </div>

          {/* Two Supported Industry Sectors */}
          <div>
            <h4 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
              <HeartHandshake className="w-4 h-4 text-purple-600" />
              Two Supported Operational Sectors
            </h4>
            <div className="space-y-3">
              <div className="p-3.5 border border-slate-200 rounded-xl flex gap-3 items-start">
                <div className="p-2 bg-amber-100 text-amber-800 rounded-lg shrink-0 mt-0.5">
                  <HardHat className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="font-semibold text-slate-900 text-xs sm:text-sm">
                    1. Construction & Civil Infrastructure
                  </h5>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Tackles hazardous conditions (scaffolding heights, crane zones, high ambient heat),
                    prolonged concrete pours extending into overtime, and migrant worker language barriers
                    via Hindi and Gujarati interface access.
                  </p>
                </div>
              </div>

              <div className="p-3.5 border border-slate-200 rounded-xl flex gap-3 items-start">
                <div className="p-2 bg-indigo-100 text-indigo-800 rounded-lg shrink-0 mt-0.5">
                  <School className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="font-semibold text-slate-900 text-xs sm:text-sm">
                    2. College & Campus Facilities (e.g., SRM University)
                  </h5>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Covers institutional maintenance teams, HVAC technicians, lab chemical waste
                    handling, sanitation, and electrical crew operating on complex rotating campus shifts.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Verification Highlights */}
          <div className="border-t border-slate-200 pt-4">
            <h4 className="font-semibold text-slate-900 text-xs mb-2">Hackathon Prototype Integrity</h4>
            <ul className="text-xs text-slate-600 space-y-1.5">
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                Dual-persona access: Switch seamlessly between Worker Portal and Employer Command.
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                Zero paid APIs or telemetry bloat: runs client-side with persistent browser synchronization.
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                Accessible contrast, large touch targets (≥44px), and trilingual UI support.
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 text-sm font-semibold bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors shadow-sm focus:ring-2 focus:ring-slate-400"
          >
            Close & Continue Exploring
          </button>
        </div>
      </div>
    </div>
  );
};
