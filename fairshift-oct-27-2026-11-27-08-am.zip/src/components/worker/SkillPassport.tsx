import React, { useState } from 'react';
import {
  Award,
  CheckCircle2,
  Calendar,
  Building2,
  FileCheck,
  User,
  Shield,
  Download,
  X,
  ExternalLink,
} from 'lucide-react';
import { Language, WorkerProfile } from '../../types';
import { translations } from '../../utils/translations';

interface SkillPassportProps {
  lang: Language;
  worker: WorkerProfile;
}

export const SkillPassport: React.FC<SkillPassportProps> = ({
  lang,
  worker,
}) => {
  const t = translations[lang];
  const [showCardModal, setShowCardModal] = useState<boolean>(false);

  return (
    <div className="space-y-6">
      {/* Worker Identity Overview */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-700">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">{t.passportTitle}</h2>
              <p className="text-xs text-slate-500 mt-0.5">{t.passportSubtitle}</p>
            </div>
          </div>
          <button
            onClick={() => setShowCardModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer self-start sm:self-auto"
          >
            <FileCheck className="w-4 h-4" />
            <span>{t.downloadCredential}</span>
          </button>
        </div>

        {/* Worker Profile Card */}
        <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="text-xs text-slate-500 font-medium">Worker Name & ID</div>
            <div className="text-base font-bold text-slate-900 mt-1">{worker.name}</div>
            <div className="text-xs font-mono text-slate-600 mt-0.5">{worker.employeeId}</div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
            <div className="text-xs text-slate-500 font-medium">Primary Specialization</div>
            <div className="text-sm font-bold text-slate-900 mt-1">{worker.role}</div>
            <div className="text-xs text-slate-600 mt-0.5">
              {worker.industry === 'construction'
                ? 'Infrastructure & Civil'
                : 'Campus Facilities & HVAC'}
            </div>
          </div>

          <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200">
            <div className="text-xs text-emerald-900 font-medium">{t.trainingHours}</div>
            <div className="text-2xl font-black text-emerald-950 mt-1 tabular-nums">
              {worker.completedTrainingHours} hrs
            </div>
            <div className="text-xs text-emerald-800 mt-0.5 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Full statutory compliance</span>
            </div>
          </div>
        </div>
      </div>

      {/* Certifications List */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <h3 className="font-bold text-slate-900 text-base mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5 text-blue-600" />
          <span>{t.certificationsTitle}</span>
        </h3>

        <div className="space-y-3">
          {worker.certifications.map((cert) => (
            <div
              key={cert.id}
              className="p-4 rounded-xl border border-slate-200/80 hover:border-slate-300 transition-colors bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-slate-900 text-sm">{cert.title}</span>
                  <span className="bg-blue-50 text-blue-700 text-[10px] font-bold px-2 py-0.5 rounded border border-blue-200">
                    {cert.level}
                  </span>
                  {cert.verified && (
                    <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      {t.verifiedBadge}
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-600">
                  Authority: <strong className="text-slate-800">{cert.issuingAuthority}</strong>
                </div>
                <div className="text-xs text-slate-500 flex items-center gap-3">
                  <span>Issued: {cert.issueDate}</span>
                  <span aria-hidden="true">·</span>
                  <span>Valid through: {cert.expiryDate}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-[10px]">{cert.id}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Credential Card Modal */}
      {showCardModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden">
            {/* ID Card Front */}
            <div className="bg-gradient-to-r from-blue-700 to-indigo-800 p-5 text-white">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  <Shield className="w-6 h-6 text-blue-200" />
                  <div>
                    <div className="text-xs font-bold tracking-widest text-blue-200 uppercase">
                      FairShift Verified Pass
                    </div>
                    <div className="text-base font-extrabold leading-tight">WORKFORCE SKILL PASSPORT</div>
                  </div>
                </div>
                <button
                  onClick={() => setShowCardModal(false)}
                  className="p-1 text-white/80 hover:text-white rounded-lg"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-6 flex items-center gap-4">
                <div className="w-16 h-16 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center text-white font-bold text-2xl">
                  {worker.name.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-lg leading-tight">{worker.name}</div>
                  <div className="text-xs text-blue-200">{worker.role}</div>
                  <div className="font-mono text-xs text-blue-300 mt-1">ID: {worker.employeeId}</div>
                </div>
              </div>
            </div>

            {/* ID Card Details */}
            <div className="p-5 space-y-3 text-xs text-slate-700">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Current Industry</span>
                <span className="font-semibold text-slate-900 capitalize">{worker.industry}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Assigned Worksite</span>
                <span className="font-semibold text-slate-900 text-right truncate max-w-[200px]">
                  {worker.worksite}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Completed Training</span>
                <span className="font-semibold text-emerald-700 font-mono">
                  {worker.completedTrainingHours} Hours Logged
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Verification Standard</span>
                <span className="font-semibold text-slate-900">UN SDG 8 / NSDC Aligned</span>
              </div>

              <div className="pt-3">
                <button
                  onClick={() => setShowCardModal(false)}
                  className="w-full py-2.5 bg-slate-900 text-white font-semibold text-xs rounded-xl hover:bg-slate-800 transition-colors"
                >
                  Close Pass Preview
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
