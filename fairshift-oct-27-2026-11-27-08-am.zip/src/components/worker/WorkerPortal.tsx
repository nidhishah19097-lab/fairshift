import React, { useState, useEffect } from 'react';
import {
  Clock,
  IndianRupee,
  ShieldAlert,
  Activity,
  Award,
  HardHat,
  Building,
  User,
  Radio,
} from 'lucide-react';
import { Language, WorkerProfile } from '../../types';
import { translations } from '../../utils/translations';
import { getCurrentWorker, getActiveShift } from '../../utils/storage';
import { SmartAttendance } from './SmartAttendance';
import { WageTransparency } from './WageTransparency';
import { SafeVoice } from './SafeVoice';
import { FatigueGuard } from './FatigueGuard';
import { SkillPassport } from './SkillPassport';
import { ToastMessage } from '../NotificationToast';

interface WorkerPortalProps {
  lang: Language;
  onNotify: (toast: ToastMessage) => void;
}

export type WorkerTab = 'attendance' | 'wage' | 'safevoice' | 'fatigue' | 'passport';

export const WorkerPortal: React.FC<WorkerPortalProps> = ({ lang, onNotify }) => {
  const t = translations[lang];
  const [activeTab, setActiveTab] = useState<WorkerTab>('attendance');
  const [worker, setWorker] = useState<WorkerProfile>(getCurrentWorker());
  const [activeShift, setActiveShift] = useState(getActiveShift());

  useEffect(() => {
    const handleStorageUpdate = () => {
      setWorker(getCurrentWorker());
      setActiveShift(getActiveShift());
    };
    window.addEventListener('fairshift_storage_update', handleStorageUpdate);
    return () => window.removeEventListener('fairshift_storage_update', handleStorageUpdate);
  }, []);

  const navItems = [
    { id: 'attendance' as WorkerTab, label: t.tabAttendance, icon: Clock },
    { id: 'wage' as WorkerTab, label: t.tabWage, icon: IndianRupee },
    { id: 'safevoice' as WorkerTab, label: t.tabSafeVoice, icon: ShieldAlert },
    { id: 'fatigue' as WorkerTab, label: t.tabFatigue, icon: Activity },
    { id: 'passport' as WorkerTab, label: t.tabPassport, icon: Award },
  ];

  return (
    <div className="space-y-6 pb-20 md:pb-6">
      {/* Worker Context Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-700 flex items-center justify-center font-bold text-lg shrink-0">
            {worker.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">
                {worker.name}
              </h1>
              <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                {worker.employeeId}
              </span>
              {activeShift && (
                <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2 py-0.5 rounded flex items-center gap-1.5 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
                  {t.liveStatus}
                </span>
              )}
            </div>
            <div className="text-xs text-slate-500 flex items-center gap-2 mt-1 flex-wrap">
              <span className="font-medium text-slate-700">{worker.role}</span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                {worker.industry === 'construction' ? (
                  <HardHat className="w-3.5 h-3.5 text-amber-600" />
                ) : (
                  <Building className="w-3.5 h-3.5 text-indigo-600" />
                )}
                <span>
                  {worker.industry === 'construction'
                    ? 'Construction Site'
                    : 'College & Campus Facilities'}
                </span>
              </span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-600">Base: ₹{worker.baseHourlyRate}/hr</span>
            </div>
          </div>
        </div>

        {/* Quick Industry Context Switcher for Demonstration */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            onClick={() => {
              const updatedWorker: WorkerProfile = {
                ...worker,
                industry: 'construction',
                role: 'Senior Rigging & Scaffolding Lead',
                worksite: 'Metro Expansion Project - Phase 4 (Pillar 142)',
                baseHourlyRate: 140,
              };
              setWorker(updatedWorker);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
              worker.industry === 'construction'
                ? 'bg-amber-50 text-amber-900 border-amber-300 shadow-xs'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Construction Persona
          </button>
          <button
            onClick={() => {
              const updatedWorker: WorkerProfile = {
                ...worker,
                industry: 'campus',
                role: 'Senior Campus Facilities & HVAC Lead',
                worksite: 'SRM Campus - Central HVAC & Substation 3',
                baseHourlyRate: 135,
              };
              setWorker(updatedWorker);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
              worker.industry === 'campus'
                ? 'bg-indigo-50 text-indigo-900 border-indigo-300 shadow-xs'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Campus Facilities Persona
          </button>
        </div>
      </div>

      {/* Desktop / Tablet Navigation Tabs */}
      <div className="hidden md:flex items-center gap-1.5 p-1.5 bg-slate-100 rounded-2xl border border-slate-200">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-white text-blue-700 shadow-sm border border-slate-200/90'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-slate-500'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Tab Panels */}
      <div>
        {activeTab === 'attendance' && (
          <SmartAttendance lang={lang} worker={worker} onNotify={onNotify} />
        )}
        {activeTab === 'wage' && <WageTransparency lang={lang} worker={worker} />}
        {activeTab === 'safevoice' && (
          <SafeVoice lang={lang} worker={worker} onNotify={onNotify} />
        )}
        {activeTab === 'fatigue' && <FatigueGuard lang={lang} worker={worker} />}
        {activeTab === 'passport' && <SkillPassport lang={lang} worker={worker} />}
      </div>

      {/* Mobile Fixed Bottom Navigation Bar (Pattern 1 from Mobile Touch Apps skill) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-lg">
        <div className="grid grid-cols-5 items-center h-16 px-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center h-full min-h-[44px] transition-colors ${
                  isActive ? 'text-blue-600' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className="w-5 h-5 shrink-0" />
                <span className="text-[10px] font-semibold tracking-tight mt-1 truncate max-w-[62px]">
                  {item.label.split(' ')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
