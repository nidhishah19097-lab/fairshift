import React, { useState, useEffect } from 'react';
import {
  Activity,
  AlertTriangle,
  Clock,
  Heart,
  Droplets,
  Moon,
  ShieldCheck,
  Coffee,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { Language, ShiftRecord, WorkerProfile } from '../../types';
import { translations } from '../../utils/translations';
import { getActiveShift, getStoredShifts } from '../../utils/storage';

interface FatigueGuardProps {
  lang: Language;
  worker: WorkerProfile;
}

export const FatigueGuard: React.FC<FatigueGuardProps> = ({
  lang,
  worker,
}) => {
  const t = translations[lang];
  const [activeShift, setActiveShift] = useState<ShiftRecord | null>(getActiveShift());
  const [shifts, setShifts] = useState<ShiftRecord[]>(getStoredShifts());

  // Interactive simulation slider so user can test thresholds directly
  const [simulatedHours, setSimulatedHours] = useState<number>(0);
  const [useSimulation, setUseSimulation] = useState<boolean>(false);
  const [restGapHours, setRestGapHours] = useState<number>(14); // hours since prior shift ended

  useEffect(() => {
    const handleStorageUpdate = () => {
      setActiveShift(getActiveShift());
      setShifts(getStoredShifts());
    };
    window.addEventListener('fairshift_storage_update', handleStorageUpdate);
    return () => window.removeEventListener('fairshift_storage_update', handleStorageUpdate);
  }, []);

  // Compute live duration if shift is active
  let liveHours = 0;
  if (activeShift) {
    const start = new Date(activeShift.startTime).getTime();
    liveHours = Math.max(0.1, Number(((Date.now() - start) / (1000 * 3600)).toFixed(1)));
  }

  // Calculate prior shift rest gap
  useEffect(() => {
    if (shifts.length > 0 && shifts[0].endTime) {
      const lastEnd = new Date(shifts[0].endTime).getTime();
      const now = Date.now();
      const gap = Math.max(0, Number(((now - lastEnd) / (1000 * 3600)).toFixed(1)));
      setRestGapHours(gap);
    }
  }, [shifts]);

  const effectiveHours = useSimulation ? simulatedHours : liveHours;

  // Determine fatigue risk level
  const getFatigueMetrics = (hours: number, restGap: number) => {
    if (hours >= 11 || restGap < 8) {
      return {
        level: 'critical',
        label: t.fatigueCritical,
        color: 'text-rose-700 bg-rose-50 border-rose-300',
        badgeColor: 'bg-rose-600 text-white',
        advice:
          'CRITICAL REST ALERT: Maximum statutory safe working hours exceeded. Immediate cessation of heavy equipment operation, scaffolding work, or driving required.',
        hydration: 'Mandatory 30-minute cooling rest with rehydration before transit.',
        recommendedRestHours: 12,
      };
    } else if (hours >= 8.5 || restGap < 11) {
      return {
        level: 'warning',
        label: t.fatigueWarning,
        color: 'text-amber-800 bg-amber-50 border-amber-300',
        badgeColor: 'bg-amber-600 text-white',
        advice:
          'OVERTIME WARNING: Extended shift detected. Decreased reaction time and high cognitive fatigue likely. Avoid solo work at heights.',
        hydration: 'Take a 15-minute shaded rest break and consume at least 500ml water.',
        recommendedRestHours: 10,
      };
    } else if (hours >= 6) {
      return {
        level: 'caution',
        label: t.fatigueCaution,
        color: 'text-yellow-800 bg-yellow-50 border-yellow-200',
        badgeColor: 'bg-yellow-500 text-slate-900',
        advice:
          'MODERATE WORKLOAD: Approaching full shift benchmark. Ensure buddy check before remaining tasks.',
        hydration: 'Standard hydration interval reminder.',
        recommendedRestHours: 8,
      };
    } else {
      return {
        level: 'normal',
        label: t.fatigueNormal,
        color: 'text-emerald-800 bg-emerald-50 border-emerald-300',
        badgeColor: 'bg-emerald-600 text-white',
        advice:
          'SAFE ZONE: Shift hours within normal statutory safety parameters. Energy levels and alertness optimal.',
        hydration: 'Maintain steady hydration (1 cup per hour).',
        recommendedRestHours: 8,
      };
    }
  };

  const metrics = getFatigueMetrics(effectiveHours, restGapHours);

  return (
    <div className="space-y-6">
      {/* Header card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-50 text-purple-700">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">{t.fatigueTitle}</h2>
              <p className="text-xs text-slate-500 mt-0.5">{t.fatigueSubtitle}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-start sm:self-auto text-xs font-semibold text-slate-600 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
            <Clock className="w-3.5 h-3.5" />
            <span>Rest Benchmark: ≥11h Daily Gap</span>
          </div>
        </div>

        {/* Current Fatigue Status Display */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-slate-500">{t.consecutiveHours}</div>
              <div className="text-3xl font-extrabold text-slate-900 mt-1 tabular-nums">
                {effectiveHours.toFixed(1)} <span className="text-sm font-normal text-slate-500">hrs</span>
              </div>
            </div>
            <div className="text-[11px] text-slate-500 mt-2">
              {activeShift && !useSimulation
                ? 'Active shift currently running'
                : useSimulation
                ? 'Simulated hypothetical shift'
                : 'No active shift right now'}
            </div>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between">
            <div>
              <div className="text-xs font-semibold text-slate-500">Rest Gap Since Prior Shift</div>
              <div className="text-3xl font-extrabold text-slate-900 mt-1 tabular-nums">
                {restGapHours} <span className="text-sm font-normal text-slate-500">hrs</span>
              </div>
            </div>
            <div className="text-[11px] text-slate-500 mt-2">
              {restGapHours >= 11 ? (
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Adequate statutory rest interval
                </span>
              ) : (
                <span className="text-rose-700 font-semibold flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Insufficient recovery gap (&lt;11h)
                </span>
              )}
            </div>
          </div>

          <div className={`p-4 rounded-xl border flex flex-col justify-between ${metrics.color}`}>
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider">{t.fatigueLevel}</div>
              <div className="text-xl font-black mt-1 leading-snug">{metrics.label}</div>
            </div>
            <div className="mt-2">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${metrics.badgeColor}`}>
                Threshold Matrix Alert
              </span>
            </div>
          </div>
        </div>

        {/* Actionable Advice Box */}
        <div className="mt-6 p-4 rounded-xl border border-slate-200 bg-slate-50/70 space-y-3">
          <div className="flex items-start gap-3">
            <Heart className="w-5 h-5 text-purple-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-slate-900 text-xs sm:text-sm">
                Safety Guidance & Physiological Countermeasures
              </div>
              <p className="text-xs text-slate-700 mt-1 leading-relaxed">{metrics.advice}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200/80 text-xs">
            <div className="flex items-center gap-2 text-slate-700">
              <Droplets className="w-4 h-4 text-blue-500 shrink-0" />
              <span>{metrics.hydration}</span>
            </div>
            <div className="flex items-center gap-2 text-slate-700">
              <Moon className="w-4 h-4 text-indigo-500 shrink-0" />
              <span>
                Recommended recovery sleep:{' '}
                <strong className="text-slate-900">{metrics.recommendedRestHours} hours</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Rule-Based Disclaimer (Required by prompt) */}
        <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-2.5 text-[11px] text-slate-600">
          <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
          <p className="leading-relaxed">{t.ruleBasedDisclaimer}</p>
        </div>
      </div>

      {/* Threshold Simulator & Risk Calculator */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Coffee className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              Interactive Shift Duration Risk Simulator
            </h3>
          </div>
          <button
            onClick={() => {
              setUseSimulation(!useSimulation);
              if (!useSimulation) setSimulatedHours(9.5);
            }}
            className={`text-xs font-semibold px-3 py-1.5 rounded-lg border transition-colors cursor-pointer ${
              useSimulation
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
            }`}
          >
            {useSimulation ? 'Using Simulator' : 'Test Shift Simulator'}
          </button>
        </div>

        {useSimulation ? (
          <div className="mt-4 space-y-4">
            <div>
              <div className="flex justify-between text-xs font-medium text-slate-700 mb-1.5">
                <label htmlFor="simulated-shift-hours">Hypothetical Continuous Shift Hours</label>
                <span className="font-bold text-slate-900 tabular-nums">
                  {simulatedHours.toFixed(1)} hours
                </span>
              </div>
              <input
                id="simulated-shift-hours"
                type="range"
                min="1"
                max="16"
                step="0.5"
                value={simulatedHours}
                onChange={(e) => setSimulatedHours(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-purple-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>4h (Light)</span>
                <span>8h (Standard)</span>
                <span>10h (Fatigue Alert)</span>
                <span>12h+ (Critical Danger)</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-medium text-slate-700 mb-1.5">
                <label htmlFor="simulated-rest-gap">Simulated Rest Gap Between Consecutive Shifts</label>
                <span className="font-bold text-slate-900 tabular-nums">{restGapHours} hours</span>
              </div>
              <input
                id="simulated-rest-gap"
                type="range"
                min="4"
                max="24"
                step="1"
                value={restGapHours}
                onChange={(e) => setRestGapHours(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-purple-600"
              />
            </div>
          </div>
        ) : (
          <p className="mt-3 text-xs text-slate-500 leading-relaxed">
            Click &quot;Test Shift Simulator&quot; above to see how FatigueGuard calculates fatigue risk
            levels when shifts exceed 8 hours or when turnaround time between shifts drops below the
            statutory 11-hour threshold.
          </p>
        )}
      </div>
    </div>
  );
};
