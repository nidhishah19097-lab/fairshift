import React, { useState, useEffect } from 'react';
import {
  Shield,
  Send,
  AlertTriangle,
  Lock,
  Building,
  CheckCircle2,
  Clock,
  Check,
  FileQuestion,
  Database,
} from 'lucide-react';
import {
  HazardCategory,
  Industry,
  Language,
  SafetyReport,
  SeverityLevel,
  WorkerProfile,
} from '../../types';
import { translations } from '../../utils/translations';
import {
  getStoredSafetyReports,
  saveSafetyReports,
} from '../../utils/storage';
import {
  submitSafetyReport,
  subscribeSafetyReports,
} from '../../utils/firestoreService';
import { ToastMessage } from '../NotificationToast';

interface SafeVoiceProps {
  lang: Language;
  worker: WorkerProfile;
  onNotify: (toast: ToastMessage) => void;
}

export const SafeVoice: React.FC<SafeVoiceProps> = ({
  lang,
  worker,
  onNotify,
}) => {
  const t = translations[lang];
  const [reports, setReports] = useState<SafetyReport[]>(getStoredSafetyReports());

  // Form states
  const [category, setCategory] = useState<HazardCategory>('fall_hazard');
  const [industry, setIndustry] = useState<Industry>(worker.industry);
  const [worksite, setWorksite] = useState<string>(worker.worksite);
  const [severity, setSeverity] = useState<SeverityLevel>('High');
  const [description, setDescription] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [lastSubmittedToken, setLastSubmittedToken] = useState<string | null>(null);

  // Real-time Firestore Subscription
  useEffect(() => {
    const unsubscribe = subscribeSafetyReports(
      (cloudReports) => {
        if (cloudReports.length > 0) {
          setReports(cloudReports);
        }
      },
      (err) => {
        console.warn('Falling back to local storage for safety reports:', err);
      }
    );

    const handleStorageUpdate = () => {
      setReports(getStoredSafetyReports());
    };
    window.addEventListener('fairshift_storage_update', handleStorageUpdate);

    return () => {
      unsubscribe();
      window.removeEventListener('fairshift_storage_update', handleStorageUpdate);
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      onNotify({
        id: Date.now().toString(),
        type: 'warning',
        message: 'Please provide a brief description of the hazard condition.',
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const randomTokenNumber = Math.floor(1000 + Math.random() * 9000);
      const generatedToken = `#ANON-${randomTokenNumber}`;
      const reportId = `SV-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;

      const newReport: SafetyReport = {
        id: reportId,
        anonymousToken: generatedToken,
        timestamp: new Date().toISOString(),
        industry,
        worksite,
        category,
        severity,
        description: description.trim(),
        status: 'Open',
        adminNotes: '',
        isDemoData: false,
      };

      // 1. Update local cache
      const updated = [newReport, ...reports];
      saveSafetyReports(updated);
      setReports(updated);

      // 2. Persist to Cloud Firestore
      try {
        await submitSafetyReport(newReport);
      } catch (err) {
        console.warn('Report stored locally; cloud sync pending network.');
      }

      setLastSubmittedToken(generatedToken);
      setDescription('');

      onNotify({
        id: Date.now().toString(),
        type: 'success',
        message: `${t.reportSubmittedSuccess} ${generatedToken} (Cloud Synced)`,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getSeverityStyle = (sev: SeverityLevel) => {
    switch (sev) {
      case 'Critical':
        return 'bg-rose-50 border-rose-200 text-rose-800';
      case 'High':
        return 'bg-amber-50 border-amber-200 text-amber-800';
      case 'Medium':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800';
      default:
        return 'bg-blue-50 border-blue-200 text-blue-800';
    }
  };

  const getStatusBadge = (status: SafetyReport['status']) => {
    switch (status) {
      case 'Resolved':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-md">
            <Check className="w-3 h-3" />
            {t.statusResolved}
          </span>
        );
      case 'In Progress':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-md">
            <Clock className="w-3 h-3" />
            {t.statusInProgress}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-800 bg-blue-100 px-2.5 py-0.5 rounded-md">
            <AlertTriangle className="w-3 h-3" />
            {t.statusOpen}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Privacy Shield Banner */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-600/30 border border-blue-400/30 rounded-xl text-blue-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">{t.safeVoiceTitle}</h2>
              <p className="text-xs text-slate-300 mt-0.5">{t.safeVoiceSubtitle}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
            <div className="text-xs bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg text-emerald-400 font-semibold flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5" />
              <span>Identity Shielded</span>
            </div>
            <div className="text-[11px] bg-slate-800 border border-slate-700 px-2.5 py-1.5 rounded-lg text-blue-300 font-semibold flex items-center gap-1.5">
              <Database className="w-3 h-3 text-blue-400" />
              <span>Firestore Sync</span>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-300 leading-relaxed">
          {t.safeVoiceShieldNotice}
        </div>
      </div>

      {/* Confirmation Token Card if just submitted */}
      {lastSubmittedToken && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 text-emerald-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-sm">{t.yourAnonymousToken}</div>
              <div className="text-xl font-extrabold text-emerald-800 font-mono tracking-wider mt-0.5">
                {lastSubmittedToken}
              </div>
              <div className="text-xs text-emerald-700 mt-1">{t.tokenInstruction}</div>
            </div>
          </div>
          <button
            onClick={() => setLastSubmittedToken(null)}
            className="text-xs font-semibold px-3 py-1.5 bg-emerald-200/60 hover:bg-emerald-200 text-emerald-900 rounded-lg transition-colors cursor-pointer"
          >
            Dismiss Receipt
          </button>
        </div>
      )}

      {/* Report Hazard Form */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <h3 className="font-bold text-slate-900 text-base mb-4 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
          <span>{t.reportHazardBtn}</span>
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Category */}
            <div>
              <label htmlFor="hazard-category-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.categoryLabel}
              </label>
              <select
                id="hazard-category-select"
                value={category}
                onChange={(e) => setCategory(e.target.value as HazardCategory)}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-800 focus:ring-2 focus:ring-blue-500"
              >
                <option value="fall_hazard">Scaffolding / Working at Heights Fall Hazard</option>
                <option value="machinery">Heavy Machinery / Blind Spots / Crane Swing</option>
                <option value="electrical">Exposed Electrical Wiring / Transformer Sparking</option>
                <option value="chemical_dust">Chemical Solvent / Toxic Dust / Lack of Ventilation</option>
                <option value="heat_exhaustion">Extreme Heat / Lack of Drinking Water</option>
                <option value="inadequate_ppe">Damaged / Inadequate Personal Protective Equipment (PPE)</option>
                <option value="harassment_wage">Wage Coercion / Hostile Supervision / Unsafe Hours</option>
                <option value="ergonomic_lifting">Excessive Manual Load / Ergonomic Hazard</option>
              </select>
            </div>

            {/* Severity Level */}
            <div>
              <label htmlFor="hazard-severity-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.severityLabel}
              </label>
              <select
                id="hazard-severity-select"
                value={severity}
                onChange={(e) => setSeverity(e.target.value as SeverityLevel)}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-800 focus:ring-2 focus:ring-blue-500"
              >
                <option value="Low">Low — Housekeeping / Minor repair required</option>
                <option value="Medium">Medium — Equipment issue needing scheduled inspection</option>
                <option value="High">High — Serious danger requiring supervisor intervention today</option>
                <option value="Critical">Critical — Immediate life / limb hazard (Work must pause)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Industry */}
            <div>
              <label htmlFor="hazard-industry-select" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Industry Sector
              </label>
              <select
                id="hazard-industry-select"
                value={industry}
                onChange={(e) => setIndustry(e.target.value as Industry)}
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-800 focus:ring-2 focus:ring-blue-500"
              >
                <option value="construction">Construction Sites (Infrastructure / Metro)</option>
                <option value="campus">College & Campus Facilities (SRM Campus / Labs)</option>
              </select>
            </div>

            {/* Workplace / Location Details */}
            <div>
              <label htmlFor="worksite-input" className="block text-xs font-semibold text-slate-700 mb-1.5">
                {t.workplaceLabel}
              </label>
              <input
                id="worksite-input"
                type="text"
                value={worksite}
                onChange={(e) => setWorksite(e.target.value)}
                placeholder="Specific location or building block..."
                className="w-full p-2.5 rounded-xl border border-slate-200 bg-white text-xs font-medium text-slate-800 focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Detailed Description */}
          <div>
            <label htmlFor="hazard-description-input" className="block text-xs font-semibold text-slate-700 mb-1.5">
              {t.descriptionLabel}
            </label>
            <textarea
              id="hazard-description-input"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t.descriptionPlaceholder}
              className="w-full p-3 rounded-xl border border-slate-200 bg-white text-xs font-normal text-slate-800 focus:ring-2 focus:ring-blue-500 leading-relaxed"
            />
          </div>

          {/* Submit Action */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-slate-400" />
              <span>Direct Firestore write. No name or phone is captured.</span>
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto min-h-[44px] px-6 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-bold text-xs sm:text-sm rounded-xl shadow-sm flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? 'Securing to Firestore...' : t.submitReport}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Reports Board for this Device / Real-time Feed */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-slate-700" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              {t.recentSubmittedReports}
            </h3>
          </div>
          <span className="text-xs text-slate-500">
            {reports.length} {reports.length === 1 ? 'incident' : 'incidents'}
          </span>
        </div>

        {reports.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-500">
            <FileQuestion className="w-8 h-8 mx-auto mb-2 text-slate-400" />
            {t.noReportsWorker}
          </div>
        ) : (
          <div className="divide-y divide-slate-100 mt-2">
            {reports.map((rep) => (
              <div key={rep.id} className="py-3.5 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                      {rep.anonymousToken}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border ${getSeverityStyle(
                        rep.severity
                      )}`}
                    >
                      {rep.severity} Severity
                    </span>
                    <span className="text-xs text-slate-500">
                      {rep.industry === 'construction' ? 'Construction' : 'Campus Facilities'}
                    </span>
                  </div>
                  <div>{getStatusBadge(rep.status)}</div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed">{rep.description}</p>

                <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-500 pt-1">
                  <span>Location: <strong className="text-slate-800">{rep.worksite}</strong></span>
                  <span>{new Date(rep.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                </div>

                {rep.adminNotes && (
                  <div className="mt-2 p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700">
                    <span className="font-semibold text-slate-900">Supervisor Update: </span>
                    {rep.adminNotes}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 leading-relaxed">
          {t.privacyBoundaryNote}
        </div>
      </div>
    </div>
  );
};
