import React, { useState } from 'react';
import {
  IndianRupee,
  HelpCircle,
  Calculator,
  ShieldAlert,
  ArrowRight,
  TrendingUp,
  Receipt,
  FileText,
} from 'lucide-react';
import { Language, WorkerProfile } from '../../types';
import { translations } from '../../utils/translations';

interface WageTransparencyProps {
  lang: Language;
  worker: WorkerProfile;
}

export const WageTransparency: React.FC<WageTransparencyProps> = ({
  lang,
  worker,
}) => {
  const t = translations[lang];

  // Editable fields with sensible defaults
  const [hourlyRate, setHourlyRate] = useState<number>(worker.baseHourlyRate || 140);
  const [regularHours, setRegularHours] = useState<number>(48); // e.g. 6 days * 8 hours standard
  const [overtimeHours, setOvertimeHours] = useState<number>(12); // 12 hours overtime in week
  const [otMultiplier, setOtMultiplier] = useState<number>(1.5); // 1.5x standard or 2.0x for rest days
  const [deductions, setDeductions] = useState<number>(450); // canteen, safety boot deposit, or PF
  const [deductionNotes, setDeductionNotes] = useState<string>('Standard statutory PF/ESI + Canteen charge');

  // Calculations
  const regularBasicPay = Math.round(hourlyRate * regularHours);
  const calculatedOtHourlyRate = hourlyRate * otMultiplier;
  const calculatedOtPay = Math.round(overtimeHours * calculatedOtHourlyRate);
  const grossEstimatedEarnings = regularBasicPay + calculatedOtPay;
  const netTakeHome = Math.max(0, grossEstimatedEarnings - deductions);

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
          <div className="p-2.5 rounded-xl bg-blue-50 text-blue-700">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">{t.wageTitle}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{t.wageSubtitle}</p>
          </div>
        </div>

        {/* Top Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="text-xs font-semibold text-slate-500">{t.regularPay}</div>
            <div className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
              ₹{regularBasicPay.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">
              {regularHours} hrs @ ₹{hourlyRate}/hr
            </div>
          </div>

          <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200">
            <div className="text-xs font-semibold text-amber-900 flex items-center justify-between">
              <span>{t.overtimePay}</span>
              <span className="text-[10px] font-bold bg-amber-200/80 text-amber-900 px-1.5 py-0.5 rounded">
                {otMultiplier}x Rate
              </span>
            </div>
            <div className="text-2xl font-bold text-amber-950 mt-1 tabular-nums">
              ₹{calculatedOtPay.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-amber-800 mt-0.5">
              {overtimeHours} hrs @ ₹{calculatedOtHourlyRate.toFixed(0)}/hr
            </div>
          </div>

          <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200">
            <div className="text-xs font-semibold text-blue-900">{t.netEstimatedPay}</div>
            <div className="text-2xl font-black text-blue-950 mt-1 tabular-nums">
              ₹{netTakeHome.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-blue-700 mt-0.5">
              Gross ₹{grossEstimatedEarnings.toLocaleString('en-IN')} − ₹{deductions} ded.
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Controls & Live Breakdown Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Parameters */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Receipt className="w-4 h-4 text-slate-600" />
            Wage Parameter Sliders & Inputs
          </h3>

          {/* Base Hourly Rate */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-700 mb-1.5">
              <label htmlFor="hourly-rate-input">{t.basicHourlyRate}</label>
              <span className="font-bold text-slate-900 tabular-nums">₹{hourlyRate} / hour</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                id="hourly-rate-input"
                type="range"
                min="80"
                max="350"
                step="5"
                value={hourlyRate}
                onChange={(e) => setHourlyRate(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <input
                type="number"
                min="50"
                max="1000"
                value={hourlyRate}
                onChange={(e) => setHourlyRate(Math.max(0, Number(e.target.value)))}
                className="w-20 p-1.5 text-xs font-semibold text-right border border-slate-200 rounded-lg"
                aria-label="Hourly rate value"
              />
            </div>
          </div>

          {/* Regular Hours Worked */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-700 mb-1.5">
              <label htmlFor="regular-hours-input">{t.regularHoursWorked} (Standard Shift Total)</label>
              <span className="font-bold text-slate-900 tabular-nums">{regularHours} hours</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                id="regular-hours-input"
                type="range"
                min="0"
                max="60"
                step="1"
                value={regularHours}
                onChange={(e) => setRegularHours(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <input
                type="number"
                min="0"
                max="100"
                value={regularHours}
                onChange={(e) => setRegularHours(Math.max(0, Number(e.target.value)))}
                className="w-20 p-1.5 text-xs font-semibold text-right border border-slate-200 rounded-lg"
                aria-label="Regular hours value"
              />
            </div>
          </div>

          {/* Overtime Hours Worked */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-700 mb-1.5">
              <label htmlFor="overtime-hours-input">{t.overtimeHours}</label>
              <span className="font-bold text-amber-700 tabular-nums">+{overtimeHours} hours</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                id="overtime-hours-input"
                type="range"
                min="0"
                max="40"
                step="0.5"
                value={overtimeHours}
                onChange={(e) => setOvertimeHours(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-600"
              />
              <input
                type="number"
                min="0"
                max="80"
                step="0.5"
                value={overtimeHours}
                onChange={(e) => setOvertimeHours(Math.max(0, Number(e.target.value)))}
                className="w-20 p-1.5 text-xs font-semibold text-right border border-slate-200 rounded-lg text-amber-900"
                aria-label="Overtime hours value"
              />
            </div>
          </div>

          {/* Overtime Multiplier Selection */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              {t.overtimeMultiplier}
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setOtMultiplier(1.5)}
                className={`p-2.5 rounded-xl border text-center font-semibold transition-all ${
                  otMultiplier === 1.5
                    ? 'border-blue-600 bg-blue-50 text-blue-700'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                1.5x (Weekdays / Standard)
              </button>
              <button
                type="button"
                onClick={() => setOtMultiplier(2.0)}
                className={`p-2.5 rounded-xl border text-center font-semibold transition-all ${
                  otMultiplier === 2.0
                    ? 'border-blue-600 bg-blue-50 text-blue-700'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                2.0x (Double Pay / Sunday / Night)
              </button>
            </div>
          </div>

          {/* Statutory / Other Deductions */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-700 mb-1.5">
              <label htmlFor="deductions-input">{t.statutoryDeductions}</label>
              <span className="font-bold text-rose-700 tabular-nums">− ₹{deductions}</span>
            </div>
            <div className="flex items-center gap-3">
              <input
                id="deductions-input"
                type="number"
                min="0"
                max="10000"
                value={deductions}
                onChange={(e) => setDeductions(Math.max(0, Number(e.target.value)))}
                className="w-full p-2 text-xs font-semibold border border-slate-200 rounded-lg"
              />
            </div>
            <input
              type="text"
              value={deductionNotes}
              onChange={(e) => setDeductionNotes(e.target.value)}
              placeholder="Reason for deductions (e.g., Canteen, ESI insurance)"
              className="mt-1.5 w-full p-2 text-[11px] text-slate-600 border border-slate-200 rounded-lg bg-slate-50"
            />
          </div>
        </div>

        {/* Itemized Transparent Breakdown Receipt */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-slate-700" />
                <h3 className="font-bold text-slate-900 text-sm">{t.paySlipBreakdown}</h3>
              </div>
              <span className="text-[11px] font-semibold text-slate-500">
                INR (₹) Standard Audit
              </span>
            </div>

            <div className="space-y-3 mt-4 text-xs">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-600">Base Wage ({regularHours} hrs × ₹{hourlyRate})</span>
                <span className="font-semibold text-slate-900 tabular-nums">
                  ₹{regularBasicPay.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="flex justify-between py-1.5 border-b border-slate-100 bg-amber-50/50 px-2 rounded">
                <div className="flex items-center gap-1.5 text-amber-900">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>
                    Overtime Pay ({overtimeHours} hrs × ₹{calculatedOtHourlyRate.toFixed(0)})
                  </span>
                </div>
                <span className="font-bold text-amber-900 tabular-nums">
                  + ₹{calculatedOtPay.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span className="font-bold text-slate-800">{t.grossPay}</span>
                <span className="font-bold text-slate-900 tabular-nums">
                  ₹{grossEstimatedEarnings.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="flex justify-between py-1.5 border-b border-slate-100 text-rose-700 px-2 bg-rose-50/50 rounded">
                <span>Deductions ({deductionNotes})</span>
                <span className="font-semibold tabular-nums">− ₹{deductions.toLocaleString('en-IN')}</span>
              </div>

              <div className="flex justify-between pt-3 pb-1 text-sm border-t border-slate-200">
                <span className="font-extrabold text-blue-900">{t.netEstimatedPay}</span>
                <span className="font-extrabold text-blue-900 text-base tabular-nums">
                  ₹{netTakeHome.toLocaleString('en-IN')}
                </span>
              </div>
            </div>
          </div>

          {/* Statutory Disclaimer Note */}
          <div className="mt-6 p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
            <div className="flex items-center gap-2 text-slate-900 font-semibold text-xs mb-1">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
              <span>{t.wageDisclaimerTitle}</span>
            </div>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              {t.wageDisclaimerText}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
