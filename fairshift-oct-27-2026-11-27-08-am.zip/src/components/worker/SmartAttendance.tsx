import React, { useState, useEffect } from 'react';
import {
  Play,
  Square,
  Clock,
  Calendar,
  AlertCircle,
  Building,
  HardHat,
  TrendingUp,
  Database,
  CloudCheck,
  RefreshCw,
} from 'lucide-react';
import { Language, ShiftRecord, WorkerProfile } from '../../types';
import { translations } from '../../utils/translations';
import {
  getActiveShift,
  saveActiveShift,
  getStoredShifts,
  saveShifts,
} from '../../utils/storage';
import {
  createShiftRecord,
  updateShiftRecord,
  subscribeWorkerShifts,
} from '../../utils/firestoreService';
import { useAuth } from '../../context/AuthContext';
import { ToastMessage } from '../NotificationToast';

interface SmartAttendanceProps {
  lang: Language;
  worker: WorkerProfile;
  onNotify: (toast: ToastMessage) => void;
}

export const SmartAttendance: React.FC<SmartAttendanceProps> = ({
  lang,
  worker,
  onNotify,
}) => {
  const t = translations[lang];
  const { firebaseUser } = useAuth();
  const [activeShift, setActiveShiftState] = useState<ShiftRecord | null>(getActiveShift());
  const [shifts, setShifts] = useState<ShiftRecord[]>(getStoredShifts());
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [standardHours, setStandardHours] = useState<number>(worker.standardShiftHours || 8.0);
  const [selectedWorksite, setSelectedWorksite] = useState<string>(worker.worksite);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Firestore real-time shift sync when signed in
  useEffect(() => {
    if (firebaseUser?.uid) {
      setIsSyncing(true);
      const unsubscribe = subscribeWorkerShifts(
        firebaseUser.uid,
        (cloudShifts) => {
          if (cloudShifts.length > 0) {
            setShifts(cloudShifts);
            // Check if there is an active shift in cloud
            const activeCloud = cloudShifts.find((s) => s.status === 'active');
            if (activeCloud) {
              setActiveShiftState(activeCloud);
              saveActiveShift(activeCloud);
            }
          }
          setIsSyncing(false);
        },
        (err) => {
          console.warn('Falling back to local cache for shifts:', err);
          setIsSyncing(false);
        }
      );
      return () => unsubscribe();
    } else {
      // Offline / Local fallback listener
      const handleStorageChange = () => {
        setActiveShiftState(getActiveShift());
        setShifts(getStoredShifts());
      };
      window.addEventListener('fairshift_storage_update', handleStorageChange);
      return () => window.removeEventListener('fairshift_storage_update', handleStorageChange);
    }
  }, [firebaseUser?.uid]);

  // Shift duration live timer
  useEffect(() => {
    if (!activeShift) {
      setElapsedSeconds(0);
      return;
    }

    const calculateElapsed = () => {
      const start = new Date(activeShift.startTime).getTime();
      const now = Date.now();
      const diffSec = Math.max(0, Math.floor((now - start) / 1000));
      setElapsedSeconds(diffSec);
    };

    calculateElapsed();
    const interval = setInterval(calculateElapsed, 1000);
    return () => clearInterval(interval);
  }, [activeShift]);

  const formatTimer = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins
      .toString()
      .padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartShift = async () => {
    if (activeShift) {
      onNotify({
        id: Date.now().toString(),
        type: 'error',
        message: t.shiftAlreadyActiveError,
      });
      return;
    }

    const now = new Date();
    const shiftId = `SH-${Date.now().toString().slice(-6)}`;
    const effectiveWorkerId = firebaseUser?.uid || worker.id;

    const newShift: ShiftRecord = {
      id: shiftId,
      workerId: effectiveWorkerId,
      workerName: worker.name,
      industry: worker.industry,
      worksite: selectedWorksite,
      startTime: now.toISOString(),
      endTime: null,
      standardHours: standardHours,
      totalHours: 0,
      overtimeHours: 0,
      hourlyRate: worker.baseHourlyRate,
      overtimeMultiplier: worker.overtimeMultiplier || 1.5,
      overtimePay: 0,
      estimatedPay: 0,
      status: 'active',
    };

    // Save locally
    saveActiveShift(newShift);
    setActiveShiftState(newShift);

    // Persist to Cloud Firestore if signed in
    if (firebaseUser) {
      try {
        await createShiftRecord(newShift);
      } catch (err) {
        console.warn('Offline mode: shift saved locally and queued for cloud sync.');
      }
    }

    onNotify({
      id: Date.now().toString(),
      type: 'success',
      message: `${t.shiftStartedSuccess} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} (Cloud Synced)`,
    });
  };

  const handleEndShift = async () => {
    if (!activeShift) {
      onNotify({
        id: Date.now().toString(),
        type: 'error',
        message: t.shiftNotStartedError,
      });
      return;
    }

    const endTime = new Date();
    const startTime = new Date(activeShift.startTime);
    const diffHours = Math.max(0.05, Number(((endTime.getTime() - startTime.getTime()) / (1000 * 3600)).toFixed(2)));
    const regularHours = Math.min(diffHours, activeShift.standardHours);
    const otHours = Math.max(0, Number((diffHours - activeShift.standardHours).toFixed(2)));
    const regularPay = Math.round(regularHours * activeShift.hourlyRate);
    const otPay = Math.round(otHours * activeShift.hourlyRate * activeShift.overtimeMultiplier);
    const totalEst = regularPay + otPay;

    const completedShift: ShiftRecord = {
      ...activeShift,
      endTime: endTime.toISOString(),
      totalHours: diffHours,
      overtimeHours: otHours,
      overtimePay: otPay,
      estimatedPay: totalEst,
      status: 'completed',
    };

    // Update local cache
    const updatedShifts = [completedShift, ...shifts.filter((s) => s.id !== activeShift.id)];
    saveShifts(updatedShifts);
    setShifts(updatedShifts);
    saveActiveShift(null);
    setActiveShiftState(null);

    // Update Cloud Firestore
    if (firebaseUser) {
      try {
        await updateShiftRecord(activeShift.id, {
          endTime: completedShift.endTime,
          totalHours: diffHours,
          overtimeHours: otHours,
          overtimePay: otPay,
          estimatedPay: totalEst,
          status: 'completed',
        });
      } catch (err) {
        console.warn('Shift completed locally; cloud sync pending network.');
      }
    }

    onNotify({
      id: Date.now().toString(),
      type: 'success',
      message: `${t.shiftEndedSuccess} ${diffHours} hrs (Earned: ₹${totalEst})`,
    });
  };

  const currentDurationHours = elapsedSeconds / 3600;
  const currentOvertimeHours = Math.max(0, currentDurationHours - standardHours);

  return (
    <div className="space-y-6">
      {/* Attendance Action Control Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-600" />
              <h2 className="text-lg font-bold text-slate-900">{t.attendanceTitle}</h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">{t.attendanceSubtitle}</p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
            <span className="text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg">
              {t.standardShift}
            </span>
            <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-1.5 rounded-lg flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              <span>Firestore Connected</span>
            </span>
          </div>
        </div>

        {/* Live Shift State & Clock Controls */}
        <div className="py-6 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Shift status & counter */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <div className="text-xs font-semibold tracking-wider text-slate-500 uppercase">
              {activeShift ? t.shiftActive : 'No Shift in Progress'}
            </div>
            <div
              className={`text-4xl sm:text-5xl font-extrabold tracking-tight tabular-nums mt-1 ${
                activeShift ? 'text-blue-700' : 'text-slate-400'
              }`}
            >
              {activeShift ? formatTimer(elapsedSeconds) : '00:00:00'}
            </div>
            {activeShift && (
              <div className="text-xs text-slate-600 mt-2 flex flex-wrap items-center justify-center md:justify-start gap-2">
                <span>
                  {t.clockInTime}:{' '}
                  <strong className="text-slate-900">
                    {new Date(activeShift.startTime).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </strong>
                </span>
                <span aria-hidden="true">·</span>
                <span className="text-slate-600">
                  {t.worksiteLabel}: <strong className="text-slate-900">{activeShift.worksite}</strong>
                </span>
                {currentOvertimeHours > 0 && (
                  <span className="text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded border border-amber-200 text-[11px]">
                    +{currentOvertimeHours.toFixed(1)}h Overtime Logged
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Shift Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
            {!activeShift ? (
              <button
                onClick={handleStartShift}
                className="w-full sm:w-auto min-h-[48px] px-6 py-3 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-bold text-sm rounded-xl shadow-md shadow-blue-600/20 flex items-center justify-center gap-2.5 transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>{t.startShift}</span>
              </button>
            ) : (
              <button
                onClick={handleEndShift}
                className="w-full sm:w-auto min-h-[48px] px-6 py-3 bg-rose-600 hover:bg-rose-700 active:scale-98 text-white font-bold text-sm rounded-xl shadow-md shadow-rose-600/20 flex items-center justify-center gap-2.5 transition-all cursor-pointer"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>{t.endShift}</span>
              </button>
            )}
          </div>
        </div>

        {/* Worksite & Standard Shift Configurations */}
        {!activeShift && (
          <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label htmlFor="worksite-select" className="block font-medium text-slate-700 mb-1">
                {t.worksiteLabel}
              </label>
              <select
                id="worksite-select"
                value={selectedWorksite}
                onChange={(e) => setSelectedWorksite(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Metro Expansion Project - Phase 4 (Pillar 142)">
                  [Construction] Metro Expansion Project - Phase 4 (Pillar 142)
                </option>
                <option value="Metro Elevated Viaduct Zone B - Pier Cap Casting">
                  [Construction] Metro Elevated Viaduct Zone B - Pier Cap Casting
                </option>
                <option value="SRM Campus - Central HVAC & Substation 3">
                  [Campus] SRM Campus - Central HVAC & Substation 3
                </option>
                <option value="SRM Tech Park Labs - Sanitation & Facilities">
                  [Campus] SRM Tech Park Labs - Sanitation & Facilities
                </option>
              </select>
            </div>
            <div>
              <label htmlFor="standard-shift-select" className="block font-medium text-slate-700 mb-1">
                Standard Shift Hours Benchmark
              </label>
              <select
                id="standard-shift-select"
                value={standardHours}
                onChange={(e) => setStandardHours(Number(e.target.value))}
                className="w-full p-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value={8}>8.0 Hours (Standard Statutory Indian Shift)</option>
                <option value={9}>9.0 Hours (Factory / Extended Site Roster)</option>
                <option value={6}>6.0 Hours (High Heat / Heavy Rigging Half-Shift)</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Shifts History Log */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-slate-700" />
            <h3 className="font-bold text-slate-900 text-base">{t.shiftHistory}</h3>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            {isSyncing && <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600" />}
            <span>
              {shifts.length} {shifts.length === 1 ? 'record' : 'records'}
            </span>
          </div>
        </div>

        {shifts.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-sm">
            <AlertCircle className="w-8 h-8 mx-auto mb-2 text-slate-400" />
            {t.noShiftsYet}
          </div>
        ) : (
          <div className="divide-y divide-slate-100 mt-2">
            {shifts.map((shift) => {
              const startDate = new Date(shift.startTime);
              const endDate = shift.endTime ? new Date(shift.endTime) : null;
              const isConstruction = shift.industry === 'construction';

              return (
                <div
                  key={shift.id}
                  className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 rounded-xl px-2 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`p-2.5 rounded-xl shrink-0 mt-0.5 ${
                        isConstruction
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-indigo-50 text-indigo-800 border border-indigo-200'
                      }`}
                    >
                      {isConstruction ? (
                        <HardHat className="w-4 h-4" />
                      ) : (
                        <Building className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900 text-sm flex items-center gap-2 flex-wrap">
                        <span>{shift.worksite}</span>
                        {shift.status === 'active' && (
                          <span className="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded">
                            {t.liveStatus}
                          </span>
                        )}
                        {shift.overtimeHours > 0 && (
                          <span className="bg-amber-100 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                            <TrendingUp className="w-3 h-3" />
                            +{shift.overtimeHours.toFixed(1)}h OT
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-x-2 gap-y-1">
                        <span>
                          {startDate.toLocaleDateString(undefined, {
                            month: 'short',
                            day: 'numeric',
                          })}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>
                          {startDate.toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}{' '}
                          –{' '}
                          {endDate
                            ? endDate.toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : 'In progress'}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>Worker: {shift.workerName}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end justify-between text-right border-t sm:border-0 pt-2 sm:pt-0 border-slate-100">
                    <div className="text-sm font-bold text-slate-900 tabular-nums">
                      {shift.totalHours > 0 ? `${shift.totalHours.toFixed(1)} hrs` : 'Timing...'}
                    </div>
                    <div className="text-xs font-semibold text-emerald-700 tabular-nums">
                      Est: ₹{shift.estimatedPay > 0 ? shift.estimatedPay.toLocaleString('en-IN') : '--'}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
