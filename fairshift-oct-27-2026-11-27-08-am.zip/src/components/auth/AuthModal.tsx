import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Mail,
  User,
  KeyRound,
  Building,
  HardHat,
  School,
  AlertCircle,
  CheckCircle2,
  X,
  ArrowRight,
  Eye,
  EyeOff,
} from 'lucide-react';
import { useAuth, EMPLOYER_AUTH_CODE } from '../../context/AuthContext';
import { Industry, Language, UserRole } from '../../types';
import { translations } from '../../utils/translations';
import { ToastMessage } from '../NotificationToast';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onNotify: (toast: ToastMessage) => void;
  defaultMode?: 'signin' | 'signup_worker' | 'signup_employer';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  lang,
  onNotify,
  defaultMode = 'signin',
}) => {
  const t = translations[lang];
  const { signIn, signUpWorker, signUpEmployer, sendPasswordReset, signInDemo } = useAuth();

  const [mode, setMode] = useState<'signin' | 'signup_worker' | 'signup_employer' | 'forgot_password'>(defaultMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [industry, setIndustry] = useState<Industry>('construction');
  const [worksite, setWorksite] = useState('Metro Expansion Project - Phase 4 (Pillar 142)');
  const [employeeId, setEmployeeId] = useState('EMP-7809');
  const [baseHourlyRate, setBaseHourlyRate] = useState(140);
  const [companyName, setCompanyName] = useState('Metro Infra & SRM Maintenance Corp');
  const [authCode, setAuthCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [resetSent, setResetSent] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    try {
      if (mode === 'signin') {
        await signIn(email, password);
        onNotify({
          id: Date.now().toString(),
          type: 'success',
          message: 'Logged in successfully with Firebase Authentication.',
        });
        onClose();
      } else if (mode === 'signup_worker') {
        if (!name.trim() || !email.trim() || password.length < 6) {
          throw new Error('Please enter valid name, email and password (minimum 6 characters).');
        }
        await signUpWorker({
          email,
          pass: password,
          name,
          industry,
          worksite,
          employeeId,
          baseHourlyRate,
        });
        onNotify({
          id: Date.now().toString(),
          type: 'success',
          message: 'Worker account registered and verified via Firebase Auth.',
        });
        onClose();
      } else if (mode === 'signup_employer') {
        if (!name.trim() || !email.trim() || password.length < 6) {
          throw new Error('Please enter valid name, email and password (minimum 6 characters).');
        }
        await signUpEmployer({
          email,
          pass: password,
          name,
          industry,
          companyName,
          authCode,
        });
        onNotify({
          id: Date.now().toString(),
          type: 'success',
          message: 'Authorized Employer account registered successfully.',
        });
        onClose();
      } else if (mode === 'forgot_password') {
        if (!email.trim()) {
          throw new Error('Please enter your email address to receive password reset link.');
        }
        await sendPasswordReset(email);
        setResetSent(true);
        onNotify({
          id: Date.now().toString(),
          type: 'info',
          message: 'Password reset link sent to your email address.',
        });
      }
    } catch (err: any) {
      console.error(err);
      let msg = err.message || 'Authentication operation failed.';
      if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password')) {
        msg = 'Invalid email or password. Please check your credentials.';
      } else if (msg.includes('auth/email-already-in-use')) {
        msg = 'An account with this email address already exists.';
      } else if (msg.includes('auth/weak-password')) {
        msg = 'Password is too weak. Please use at least 6 characters.';
      }
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleDemoSignIn = async (role: UserRole) => {
    setErrorMsg(null);
    setLoading(true);
    try {
      await signInDemo(role);
      onNotify({
        id: Date.now().toString(),
        type: 'success',
        message: `Signed in as Demo ${role === 'employer' ? 'Employer' : 'Worker'} with Firebase Auth.`,
      });
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Demo authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">
                FairShift Secure Authentication
              </h2>
              <p className="text-[11px] text-slate-500">
                Firebase Auth &amp; Role-Based Access Control (RBAC)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Demo Access Bar for Judges */}
        <div className="bg-slate-50 p-4 border-b border-slate-200/80">
          <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <KeyRound className="w-3.5 h-3.5 text-blue-600" />
            <span>Fast One-Click Demo Sign-In (Evaluation)</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              disabled={loading}
              onClick={() => handleDemoSignIn('worker')}
              className="px-3 py-2 text-xs font-semibold bg-white border border-blue-200 hover:bg-blue-50 text-blue-700 rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <HardHat className="w-3.5 h-3.5 text-blue-600" />
              <span>Demo Worker</span>
            </button>
            <button
              type="button"
              disabled={loading}
              onClick={() => handleDemoSignIn('employer')}
              className="px-3 py-2 text-xs font-semibold bg-white border border-purple-200 hover:bg-purple-50 text-purple-700 rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Building className="w-3.5 h-3.5 text-purple-600" />
              <span>Demo Employer</span>
            </button>
          </div>
        </div>

        {/* Mode Selector Tabs */}
        {mode !== 'forgot_password' && (
          <div className="px-6 pt-4 flex border-b border-slate-100 text-xs font-semibold gap-1">
            <button
              type="button"
              onClick={() => {
                setMode('signin');
                setErrorMsg(null);
              }}
              className={`pb-2.5 px-2 border-b-2 transition-all ${
                mode === 'signin'
                  ? 'border-blue-600 text-blue-600 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('signup_worker');
                setErrorMsg(null);
              }}
              className={`pb-2.5 px-2 border-b-2 transition-all ${
                mode === 'signup_worker'
                  ? 'border-blue-600 text-blue-600 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Register Worker
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('signup_employer');
                setErrorMsg(null);
              }}
              className={`pb-2.5 px-2 border-b-2 transition-all ${
                mode === 'signup_employer'
                  ? 'border-purple-600 text-purple-600 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              Register Employer
            </button>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {resetSent && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-2.5 text-xs text-emerald-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Password reset instructions have been dispatched to your email!</span>
            </div>
          )}

          {/* Name field for registration */}
          {(mode === 'signup_worker' || mode === 'signup_employer') && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Full Name
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Ramesh Patel / Dr. Ananya Sharma"
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          )}

          {/* Email field */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@fairshift.demo"
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Password field */}
          {mode !== 'forgot_password' && (
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-700">Password</label>
                {mode === 'signin' && (
                  <button
                    type="button"
                    onClick={() => {
                      setMode('forgot_password');
                      setErrorMsg(null);
                    }}
                    className="text-[11px] text-blue-600 hover:underline"
                  >
                    Forgot Password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="w-full pl-9 pr-10 py-2 text-xs border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1 text-slate-400 hover:text-slate-600 absolute right-2.5 top-2"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          {/* Specific Worker Fields */}
          {mode === 'signup_worker' && (
            <div className="space-y-3 pt-1 border-t border-slate-100">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Industry Sector
                  </label>
                  <select
                    value={industry}
                    onChange={(e) => setIndustry(e.target.value as Industry)}
                    className="w-full p-2 text-xs border border-slate-200 rounded-xl bg-white"
                  >
                    <option value="construction">Construction Sites</option>
                    <option value="campus">Campus Facilities</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Base Rate (₹/hr)
                  </label>
                  <input
                    type="number"
                    value={baseHourlyRate}
                    onChange={(e) => setBaseHourlyRate(Number(e.target.value))}
                    className="w-full p-2 text-xs border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Primary Worksite
                </label>
                <input
                  type="text"
                  value={worksite}
                  onChange={(e) => setWorksite(e.target.value)}
                  className="w-full p-2 text-xs border border-slate-200 rounded-xl"
                />
              </div>
            </div>
          )}

          {/* Specific Employer Fields */}
          {mode === 'signup_employer' && (
            <div className="space-y-3 pt-1 border-t border-slate-100">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Organization / Facility Name
                </label>
                <input
                  type="text"
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="e.g., SRM Estate Management & Maintenance"
                  className="w-full p-2 text-xs border border-slate-200 rounded-xl"
                />
              </div>

              {/* Trusted Authorization Code */}
              <div className="bg-purple-50 p-3 rounded-xl border border-purple-200">
                <div className="flex justify-between items-center mb-1">
                  <label className="text-xs font-bold text-purple-950 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-purple-700" />
                    <span>Employer Verification Code</span>
                  </label>
                  <span className="text-[10px] text-purple-700 font-mono bg-purple-100 px-1.5 py-0.5 rounded">
                    Code: {EMPLOYER_AUTH_CODE}
                  </span>
                </div>
                <input
                  type="text"
                  required
                  value={authCode}
                  onChange={(e) => setAuthCode(e.target.value)}
                  placeholder={`Enter authorization code: ${EMPLOYER_AUTH_CODE}`}
                  className="w-full p-2 text-xs border border-purple-300 rounded-lg bg-white"
                />
                <p className="text-[10px] text-purple-800 mt-1">
                  Prevents workers from self-promoting to Employer role without credentials.
                </p>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className={`w-full py-2.5 px-4 font-bold text-xs rounded-xl text-white shadow-sm flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50 ${
                mode === 'signup_employer'
                  ? 'bg-purple-600 hover:bg-purple-700'
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              <span>
                {loading
                  ? 'Processing Firebase...'
                  : mode === 'signin'
                  ? 'Sign In with Firebase Auth'
                  : mode === 'signup_worker'
                  ? 'Complete Worker Registration'
                  : mode === 'signup_employer'
                  ? 'Authorize & Register Employer'
                  : 'Send Reset Email'}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {mode === 'forgot_password' && (
            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setMode('signin')}
                className="text-xs text-blue-600 hover:underline"
              >
                Back to Sign In
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
