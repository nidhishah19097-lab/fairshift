import React, { useState, useEffect } from 'react';
import {
  Users,
  Clock,
  AlertTriangle,
  ShieldAlert,
  Activity,
  CheckCircle2,
  HardHat,
  School,
  Building2,
  TrendingUp,
  BarChart3,
  Calendar,
  Check,
  Database,
  Lock,
  RefreshCw,
} from 'lucide-react';
import {
  Industry,
  Language,
  ReportStatus,
  SafetyReport,
  SeverityLevel,
  ShiftRecord,
} from '../../types';
import { translations } from '../../utils/translations';
import {
  getStoredSafetyReports,
  saveSafetyReports,
  getStoredShifts,
  getActiveShift,
} from '../../utils/storage';
import {
  subscribeAllShifts,
  subscribeSafetyReports,
  updateSafetyReportStatus,
} from '../../utils/firestoreService';
import { useAuth } from '../../context/AuthContext';
import { ToastMessage } from '../NotificationToast';

interface EmployerPortalProps {
  lang: Language;
  onNotify: (toast: ToastMessage) => void;
  onOpenAuthModal?: () => void;
}

export const EmployerPortal: React.FC<EmployerPortalProps> = ({
  lang,
  onNotify,
  onOpenAuthModal,
}) => {
  const t = translations[lang];
  const { user, isEmployer, signInDemo } = useAuth();

  // Industry filter: 'all' | 'construction' | 'campus'
  const [selectedIndustry, setSelectedIndustry] = useState<'all' | Industry>('all');
  const [shifts, setShifts] = useState<ShiftRecord[]>(getStoredShifts());
  const [reports, setReports] = useState<SafetyReport[]>(getStoredSafetyReports());
  const [activeShift, setActiveShift] = useState<ShiftRecord | null>(getActiveShift());
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Incident status edit state
  const [editingReportId, setEditingReportId] = useState<string | null>(null);
  const [editStatus, setEditStatus] = useState<ReportStatus>('In Progress');
  const [editNotes, setEditNotes] = useState<string>('');

  // Severity filter for reports
  const [severityFilter, setSeverityFilter] = useState<'all' | SeverityLevel>('all');

  // Firestore Real-Time Subscriptions for Shifts and Safety Reports
  useEffect(() => {
    setIsSyncing(true);

    const unsubShifts = subscribeAllShifts(
      (cloudShifts) => {
        if (cloudShifts.length > 0) {
          setShifts(cloudShifts);
        }
        setIsSyncing(false);
      },
      (err) => {
        console.warn('Falling back to local shifts:', err);
        setIsSyncing(false);
      }
    );

    const unsubReports = subscribeSafetyReports(
      (cloudReports) => {
        if (cloudReports.length > 0) {
          setReports(cloudReports);
        }
      },
      (err) => {
        console.warn('Falling back to local reports:', err);
      }
    );

    const handleStorageUpdate = () => {
      setActiveShift(getActiveShift());
    };
    window.addEventListener('fairshift_storage_update', handleStorageUpdate);

    return () => {
      unsubShifts();
      unsubReports();
      window.removeEventListener('fairshift_storage_update', handleStorageUpdate);
    };
  }, []);

  // Filtered dataset according to sector
  const filteredShifts = shifts.filter((s) => {
    if (selectedIndustry === 'all') return true;
    return s.industry === selectedIndustry;
  });

  const filteredReports = reports.filter((r) => {
    const matchesIndustry = selectedIndustry === 'all' || r.industry === selectedIndustry;
    const matchesSeverity = severityFilter === 'all' || r.severity === severityFilter;
    return matchesIndustry && matchesSeverity;
  });

  // Calculate KPIs
  const totalUniqueWorkers = new Set(filteredShifts.map((s) => s.workerId)).size + 2;
  const currentlyOnShiftCount =
    filteredShifts.filter((s) => s.status === 'active').length +
    (activeShift && (selectedIndustry === 'all' || activeShift.industry === selectedIndustry) ? 1 : 0);
  const overtimeAlertsCount = filteredShifts.filter((s) => s.overtimeHours > 0).length;
  const openHazardsCount = filteredReports.filter((r) => r.status === 'Open').length;
  const fatigueWarningsCount = filteredShifts.filter((s) => s.totalHours >= 9 || s.overtimeHours >= 2).length;

  // Sector Comparison metrics (Construction vs Campus)
  const constructionShifts = shifts.filter((s) => s.industry === 'construction');
  const campusShifts = shifts.filter((s) => s.industry === 'campus');

  const totalConstructionHours = constructionShifts.reduce((acc, s) => acc + s.totalHours, 0);
  const totalCampusHours = campusShifts.reduce((acc, s) => acc + s.totalHours, 0);

  const otConstructionHours = constructionShifts.reduce((acc, s) => acc + s.overtimeHours, 0);
  const otCampusHours = campusShifts.reduce((acc, s) => acc + s.overtimeHours, 0);

  const maxHours = Math.max(totalConstructionHours, totalCampusHours, 30);

  // Update incident status with Firestore
  const handleSaveStatus = async (reportId: string) => {
    // 1. Update local cache
    const updated = reports.map((rep) => {
      if (rep.id === reportId) {
        return {
          ...rep,
          status: editStatus,
          adminNotes: editNotes.trim() ? editNotes.trim() : rep.adminNotes,
          resolvedAt: editStatus === 'Resolved' ? new Date().toISOString() : rep.resolvedAt,
        };
      }
      return rep;
    });

    saveSafetyReports(updated);
    setReports(updated);

    // 2. Persist to Cloud Firestore
    try {
      await updateSafetyReportStatus(reportId, editStatus, editNotes.trim());
    } catch (err) {
      console.warn('Status updated in local cache; Firestore sync pending permissions.');
    }

    setEditingReportId(null);
    setEditNotes('');

    onNotify({
      id: Date.now().toString(),
      type: 'success',
      message: `Incident ${reportId} updated to: ${editStatus} (Cloud Synced)`,
    });
  };

  const getSeverityBadge = (sev: SeverityLevel) => {
    switch (sev) {
      case 'Critical':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-800 bg-rose-100 border border-rose-300 px-2.5 py-0.5 rounded-md">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-700" />
            <span>Critical Danger</span>
          </span>
        );
      case 'High':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2.5 py-0.5 rounded-md">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-700" />
            <span>High Risk</span>
          </span>
        );
      case 'Medium':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-yellow-900 bg-yellow-100 border border-yellow-300 px-2.5 py-0.5 rounded-md">
            <Activity className="w-3.5 h-3.5 text-yellow-700" />
            <span>Medium Priority</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-900 bg-blue-100 border border-blue-300 px-2.5 py-0.5 rounded-md">
            <ShieldAlert className="w-3.5 h-3.5 text-blue-700" />
            <span>Low / Routine</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* RBAC Role Indicator Bar */}
      {!isEmployer && (
        <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 text-purple-900">
            <Lock className="w-4 h-4 text-purple-700 shrink-0" />
            <div>
              <span className="font-bold">Demonstration Command View: </span>
              <span>
                You are previewing the Employer Portal. To exercise verified employer edits, sign in with authorized credentials.
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => signInDemo('employer')}
              className="px-3 py-1.5 bg-purple-700 text-white font-bold rounded-xl hover:bg-purple-800 transition-colors cursor-pointer"
            >
              Sign In as Authorized Employer
            </button>
            {onOpenAuthModal && (
              <button
                onClick={onOpenAuthModal}
                className="px-3 py-1.5 bg-white border border-purple-300 text-purple-700 font-semibold rounded-xl hover:bg-purple-100 transition-colors cursor-pointer"
              >
                Custom Auth
              </button>
            )}
          </div>
        </div>
      )}

      {/* Employer Header & Industry Sector Filter Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-purple-700" />
            <h1 className="text-lg sm:text-xl font-bold text-slate-900">{t.employerTitle}</h1>
            <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded flex items-center gap-1">
              <Database className="w-3 h-3 text-emerald-600" />
              <span>Firestore Active</span>
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">{t.employerSubtitle}</p>
        </div>

        {/* Industry Selector Buttons */}
        <div className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200 self-start md:self-auto flex-wrap">
          <button
            onClick={() => setSelectedIndustry('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              selectedIndustry === 'all'
                ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {t.allIndustries}
          </button>
          <button
            onClick={() => setSelectedIndustry('construction')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              selectedIndustry === 'construction'
                ? 'bg-amber-50 text-amber-900 shadow-sm border border-amber-300 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <HardHat className="w-3.5 h-3.5 text-amber-600" />
            <span>{t.industryConstruction}</span>
          </button>
          <button
            onClick={() => setSelectedIndustry('campus')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
              selectedIndustry === 'campus'
                ? 'bg-indigo-50 text-indigo-900 shadow-sm border border-indigo-300 font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <School className="w-3.5 h-3.5 text-indigo-600" />
            <span>{t.industryCampus}</span>
          </button>
        </div>
      </div>

      {/* 5 Core KPI Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        {/* Total Workers */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>{t.kpiTotalWorkers}</span>
            <Users className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-extrabold text-slate-900 mt-2 tabular-nums">
            {totalUniqueWorkers}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Live Database Pool</div>
        </div>

        {/* On Shift */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-blue-700 text-xs font-medium">
            <span>{t.kpiOnShift}</span>
            <Clock className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-extrabold text-blue-900 mt-2 tabular-nums">
            {currentlyOnShiftCount}
          </div>
          <div className="text-[10px] text-blue-600 mt-1 font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 inline-block animate-pulse" />
            Active Shifts
          </div>
        </div>

        {/* Overtime Alerts */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-amber-800 text-xs font-medium">
            <span>{t.kpiOvertimeAlerts}</span>
            <TrendingUp className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-extrabold text-amber-900 mt-2 tabular-nums">
            {overtimeAlertsCount}
          </div>
          <div className="text-[10px] text-amber-700 mt-1 font-semibold">Exceeding 8.0h Standard</div>
        </div>

        {/* Open Safety Reports */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-rose-800 text-xs font-medium">
            <span>{t.kpiOpenHazards}</span>
            <ShieldAlert className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-extrabold text-rose-900 mt-2 tabular-nums">
            {openHazardsCount}
          </div>
          <div className="text-[10px] text-rose-700 mt-1 font-semibold">Requires Supervisor Action</div>
        </div>

        {/* Fatigue Warnings */}
        <div className="col-span-2 lg:col-span-1 bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-purple-800 text-xs font-medium">
            <span>{t.kpiFatigueWarnings}</span>
            <Activity className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-extrabold text-purple-900 mt-2 tabular-nums">
            {fatigueWarningsCount}
          </div>
          <div className="text-[10px] text-purple-700 mt-1 font-semibold">High Fatigue Risk Flag</div>
        </div>
      </div>

      {/* Feature 5: Cross-Industry Overtime & Attendance Comparison Chart */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              <h2 className="text-base font-bold text-slate-900">{t.comparisonTitle}</h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">{t.comparisonSubtitle}</p>
          </div>
          <div className="text-[11px] font-semibold text-slate-500 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200 flex items-center gap-1.5">
            {isSyncing && <RefreshCw className="w-3 h-3 animate-spin text-blue-600" />}
            <span>Total Hours Logged in Firestore</span>
          </div>
        </div>

        {/* Accessible Bar Metric Visualizer */}
        <div className="mt-6 space-y-6">
          {/* Construction Site Bar */}
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-800 mb-2">
              <div className="flex items-center gap-2">
                <HardHat className="w-4 h-4 text-amber-600" />
                <span>Construction Sites (Metro & Infrastructure)</span>
              </div>
              <div className="flex items-center gap-4 text-xs tabular-nums">
                <span>Total: <strong>{totalConstructionHours.toFixed(1)} hrs</strong></span>
                <span className="text-amber-700 font-bold">
                  Overtime: +{otConstructionHours.toFixed(1)} hrs
                </span>
              </div>
            </div>
            <div className="w-full bg-slate-100 h-6 rounded-lg overflow-hidden flex">
              <div
                className="bg-amber-500 h-full transition-all duration-500"
                style={{
                  width: `${Math.min(100, ((totalConstructionHours - otConstructionHours) / maxHours) * 100)}%`,
                }}
                title={`Regular Hours: ${(totalConstructionHours - otConstructionHours).toFixed(1)}h`}
              />
              <div
                className="bg-amber-700 h-full transition-all duration-500"
                style={{
                  width: `${Math.min(100, (otConstructionHours / maxHours) * 100)}%`,
                }}
                title={`Overtime Hours: ${otConstructionHours.toFixed(1)}h`}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>Standard regular hours ({((totalConstructionHours - otConstructionHours)).toFixed(1)}h)</span>
              <span className="text-amber-800 font-medium">Overtime surge (+{otConstructionHours.toFixed(1)}h)</span>
            </div>
          </div>

          {/* Campus Facilities Bar */}
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-800 mb-2">
              <div className="flex items-center gap-2">
                <School className="w-4 h-4 text-indigo-600" />
                <span>College & Campus Facilities (SRM Campus & Labs)</span>
              </div>
              <div className="flex items-center gap-4 text-xs tabular-nums">
                <span>Total: <strong>{totalCampusHours.toFixed(1)} hrs</strong></span>
                <span className="text-indigo-700 font-bold">
                  Overtime: +{otCampusHours.toFixed(1)} hrs
                </span>
              </div>
            </div>
            <div className="w-full bg-slate-100 h-6 rounded-lg overflow-hidden flex">
              <div
                className="bg-indigo-500 h-full transition-all duration-500"
                style={{
                  width: `${Math.min(100, ((totalCampusHours - otCampusHours) / maxHours) * 100)}%`,
                }}
                title={`Regular Hours: ${(totalCampusHours - otCampusHours).toFixed(1)}h`}
              />
              <div
                className="bg-indigo-700 h-full transition-all duration-500"
                style={{
                  width: `${Math.min(100, (otCampusHours / maxHours) * 100)}%`,
                }}
                title={`Overtime Hours: ${otCampusHours.toFixed(1)}h`}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>Standard regular hours ({((totalCampusHours - otCampusHours)).toFixed(1)}h)</span>
              <span className="text-indigo-800 font-medium">Overtime surge (+{otCampusHours.toFixed(1)}h)</span>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 inline-block" />
              Regular Shift
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-amber-700 inline-block" />
              Overtime (1.5x Premium)
            </span>
          </div>
          <span>Aligned with UN SDG 8.5 (Equitable Working Hours)</span>
        </div>
      </div>

      {/* SafeVoice Incident Management Console */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              <h2 className="text-base font-bold text-slate-900">{t.incidentConsoleTitle}</h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Review and remediate hazard reports directly in Cloud Firestore without revealing worker identity
            </p>
          </div>

          {/* Severity Filter */}
          <div className="flex items-center gap-2 self-start sm:self-auto text-xs">
            <span className="text-slate-500 font-medium">{t.filterBySeverity}:</span>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value as any)}
              className="p-1.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-purple-500"
            >
              <option value="all">All Severities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>

        {/* Incidents List */}
        {filteredReports.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-500">
            {t.noIncidentsFound}
          </div>
        ) : (
          <div className="divide-y divide-slate-100 mt-2">
            {filteredReports.map((report) => {
              const isEditing = editingReportId === report.id;

              return (
                <div key={report.id} className="py-4 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                        {report.anonymousToken}
                      </span>
                      {getSeverityBadge(report.severity)}
                      <span className="text-xs text-slate-500">
                        {report.industry === 'construction' ? 'Construction Site' : 'Campus Facilities'}
                      </span>
                      <span className="text-xs text-slate-400">·</span>
                      <span className="text-xs font-semibold text-slate-700">{report.worksite}</span>
                    </div>

                    <div className="flex items-center gap-2 self-start sm:self-auto">
                      <span
                        className={`text-xs font-bold px-2.5 py-1 rounded-md ${
                          report.status === 'Resolved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : report.status === 'In Progress'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {report.status}
                      </span>
                      {!isEditing && (
                        <button
                          onClick={() => {
                            setEditingReportId(report.id);
                            setEditStatus(report.status);
                            setEditNotes(report.adminNotes || '');
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors cursor-pointer"
                        >
                          Update Status
                        </button>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-800 leading-relaxed bg-slate-50/70 p-3 rounded-xl border border-slate-100">
                    {report.description}
                  </p>

                  {/* Existing Supervisor Notes if present */}
                  {report.adminNotes && !isEditing && (
                    <div className="text-xs text-slate-600 bg-emerald-50/50 border border-emerald-100 p-2.5 rounded-lg flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-emerald-900">Remediation Log: </strong>
                        {report.adminNotes}
                      </div>
                    </div>
                  )}

                  {/* Inline Status & Note Edit Box */}
                  {isEditing && (
                    <div className="p-3.5 bg-purple-50/60 border border-purple-200 rounded-xl space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <label className="text-xs font-bold text-purple-900">
                          {t.actionUpdateStatus}:
                        </label>
                        <div className="flex items-center gap-2">
                          {(['Open', 'In Progress', 'Resolved'] as ReportStatus[]).map((st) => (
                            <button
                              key={st}
                              type="button"
                              onClick={() => setEditStatus(st)}
                              className={`px-3 py-1 text-xs font-semibold rounded-lg border transition-all ${
                                editStatus === st
                                  ? 'bg-purple-700 text-white border-purple-700 shadow-xs'
                                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                              }`}
                            >
                              {st}
                            </button>
                          ))}
                        </div>
                      </div>

                      <input
                        type="text"
                        value={editNotes}
                        onChange={(e) => setEditNotes(e.target.value)}
                        placeholder={t.notesPlaceholder}
                        className="w-full p-2 text-xs border border-purple-200 bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />

                      <div className="flex justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setEditingReportId(null)}
                          className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 rounded-lg"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveStatus(report.id)}
                          className="px-4 py-1.5 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-1.5 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>{t.saveChanges}</span>
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between items-center text-[10px] text-slate-400">
                    <span>Logged: {new Date(report.timestamp).toLocaleString()}</span>
                    <span>Firestore Document</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Live Shift & Overtime Roster */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-slate-700" />
            <h2 className="text-base font-bold text-slate-900">{t.workforceRosterTitle}</h2>
          </div>
          <span className="text-xs text-slate-500">
            {filteredShifts.length} {filteredShifts.length === 1 ? 'shift' : 'shifts'} displayed
          </span>
        </div>

        <div className="overflow-x-auto mt-2">
          <table className="w-full text-left text-xs text-slate-700">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                <th className="py-3 px-2">Worker</th>
                <th className="py-3 px-2">Worksite</th>
                <th className="py-3 px-2">Status</th>
                <th className="py-3 px-2 text-right">Logged Hours</th>
                <th className="py-3 px-2 text-right">Overtime</th>
                <th className="py-3 px-2 text-right">Est. Pay</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredShifts.map((sh) => (
                <tr key={sh.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-2">
                    <div className="font-semibold text-slate-900">{sh.workerName}</div>
                    <div className="text-[10px] text-slate-500 font-mono">{sh.workerId}</div>
                  </td>
                  <td className="py-3 px-2 max-w-[220px] truncate" title={sh.worksite}>
                    <div className="truncate text-slate-800">{sh.worksite}</div>
                    <div className="text-[10px] text-slate-500 capitalize">{sh.industry}</div>
                  </td>
                  <td className="py-3 px-2">
                    {sh.status === 'active' ? (
                      <span className="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded">
                        Active On Shift
                      </span>
                    ) : (
                      <span className="text-slate-600 text-[10px] font-medium">Completed</span>
                    )}
                  </td>
                  <td className="py-3 px-2 text-right font-bold text-slate-900 tabular-nums">
                    {sh.totalHours > 0 ? `${sh.totalHours.toFixed(1)}h` : 'Tracking...'}
                  </td>
                  <td className="py-3 px-2 text-right tabular-nums">
                    {sh.overtimeHours > 0 ? (
                      <span className="text-amber-800 font-bold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                        +{sh.overtimeHours.toFixed(1)}h
                      </span>
                    ) : (
                      <span className="text-slate-400">0.0h</span>
                    )}
                  </td>
                  <td className="py-3 px-2 text-right font-bold text-emerald-700 tabular-nums">
                    ₹{sh.estimatedPay > 0 ? sh.estimatedPay.toLocaleString('en-IN') : '--'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
