import React from 'react';
import {
  ShieldCheck,
  RotateCcw,
  Globe,
  UserCheck,
  Building2,
  LogIn,
  LogOut,
  User,
  ShieldAlert,
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  currentPortal: 'worker' | 'employer';
  onPortalChange: (portal: 'worker' | 'employer') => void;
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onResetData: () => void;
  onOpenSdgModal: () => void;
  onOpenAuthModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPortal,
  onPortalChange,
  lang,
  onLanguageChange,
  onResetData,
  onOpenSdgModal,
  onOpenAuthModal,
}) => {
  const t = translations[lang];
  const { user, isEmployer, logOut } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Prompt Wars 2026 Hackathon Demo Banner */}
      <div className="bg-slate-900 text-white text-[11px] px-4 py-1.5 flex items-center justify-between">
        <div className="flex items-center gap-2 overflow-hidden">
          <span className="font-semibold text-amber-400 uppercase tracking-wider text-[10px] whitespace-nowrap">
            Prompt Wars 2026
          </span>
          <span className="text-slate-400 hidden sm:inline" aria-hidden="true">·</span>
          <span className="text-slate-300 truncate hidden sm:inline">
            SRM ACM Student Chapter Hackathon Prototype
          </span>
          <span className="text-slate-400 hidden md:inline" aria-hidden="true">·</span>
          <span className="text-slate-400 truncate hidden md:inline">
            Firebase Auth &amp; Firestore Connected
          </span>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenSdgModal}
            className="flex items-center gap-1.5 text-xs text-amber-300 hover:text-white transition-colors focus:outline-none focus:underline"
          >
            <span className="font-bold">UN SDG 8</span>
            <span className="hidden sm:inline">Alignment</span>
          </button>
          <button
            onClick={onResetData}
            className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white transition-colors ml-2 py-0.5 px-2 rounded bg-slate-800 hover:bg-slate-700"
            title="Reset demonstration data to defaults"
          >
            <RotateCcw className="w-3 h-3" />
            <span className="hidden sm:inline">{t.resetDemoData}</span>
            <span className="sm:hidden">Reset</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar - Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onPortalChange('worker')}
            className="flex items-center gap-2.5 text-left focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-lg p-1"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-lg shadow-sm shadow-blue-600/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-lg font-bold text-slate-900 leading-none tracking-tight">
                {t.appName}
              </div>
              <div className="text-[11px] text-slate-500 font-medium tracking-tight mt-0.5">
                {t.tagline}
              </div>
            </div>
          </button>
        </div>

        {/* Zone 2: Portal Switcher (Clean Segmented Control) */}
        <nav className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200 shrink-0">
          <button
            onClick={() => onPortalChange('worker')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-semibold rounded-lg transition-all whitespace-nowrap min-h-[38px] ${
              currentPortal === 'worker'
                ? 'bg-white text-blue-700 shadow-sm border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-4 h-4 shrink-0 text-blue-600" />
            <span>{t.portalWorker}</span>
          </button>
          <button
            onClick={() => onPortalChange('employer')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-semibold rounded-lg transition-all whitespace-nowrap min-h-[38px] ${
              currentPortal === 'employer'
                ? 'bg-white text-purple-700 shadow-sm border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-4 h-4 shrink-0 text-purple-600" />
            <span>{t.portalEmployer}</span>
          </button>
        </nav>

        {/* Zone 3: Language & Auth Controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Language Selector */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2 py-1 text-xs">
            <Globe className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <select
              value={lang}
              onChange={(e) => onLanguageChange(e.target.value as Language)}
              className="bg-transparent text-slate-700 font-medium focus:outline-none cursor-pointer py-1 text-xs"
              aria-label="Select Language"
            >
              <option value="en">EN</option>
              <option value="hi">हिन्दी</option>
              <option value="gu">ગુજરાતી</option>
            </select>
          </div>

          {/* Firebase Authentication Status / Action */}
          {user ? (
            <div className="flex items-center gap-2">
              <div className="hidden lg:flex flex-col text-right">
                <span className="text-xs font-bold text-slate-900 leading-tight truncate max-w-[120px]">
                  {user.name}
                </span>
                <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-tight">
                  {isEmployer ? 'Authorized Employer' : 'Verified Worker'}
                </span>
              </div>
              <button
                onClick={logOut}
                className="p-2 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors border border-slate-200"
                title="Log Out from Firebase"
                aria-label="Log Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuthModal}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-xs transition-all cursor-pointer whitespace-nowrap"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign In</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
