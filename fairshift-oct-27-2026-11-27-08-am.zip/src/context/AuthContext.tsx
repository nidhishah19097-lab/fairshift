import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { AppUser, Industry, UserRole } from '../types';

interface AuthContextType {
  firebaseUser: FirebaseUser | null;
  user: AppUser | null;
  loading: boolean;
  isEmployer: boolean;
  signIn: (email: string, pass: string) => Promise<void>;
  signUpWorker: (params: {
    email: string;
    pass: string;
    name: string;
    industry: Industry;
    worksite: string;
    employeeId: string;
    baseHourlyRate: number;
  }) => Promise<void>;
  signUpEmployer: (params: {
    email: string;
    pass: string;
    name: string;
    industry: Industry;
    companyName: string;
    authCode: string;
  }) => Promise<void>;
  logOut: () => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
  signInDemo: (role: UserRole) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Validated registration code for authorized employer signup in this hackathon sprint
export const EMPLOYER_AUTH_CODE = 'FAIRSHIFT-2026-SRM';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<AppUser | null>(null);
  const [isEmployer, setIsEmployer] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  // Load user profile and verify role from Firestore
  const loadUserProfile = async (fbUser: FirebaseUser | null) => {
    if (!fbUser) {
      setUser(null);
      setIsEmployer(false);
      setLoading(false);
      return;
    }

    try {
      const userDocRef = doc(db, 'users', fbUser.uid);
      const userDocSnap = await getDoc(userDocRef);

      // Verify whether this user is an authorized employer via employers collection
      const employerDocRef = doc(db, 'employers', fbUser.uid);
      const employerDocSnap = await getDoc(employerDocRef);
      const hasEmployerAuth = employerDocSnap.exists();
      setIsEmployer(hasEmployerAuth);

      if (userDocSnap.exists()) {
        const data = userDocSnap.data();
        setUser({
          uid: fbUser.uid,
          email: fbUser.email || '',
          name: data.name || fbUser.displayName || 'FairShift User',
          role: hasEmployerAuth ? 'employer' : (data.role || 'worker'),
          industry: data.industry || 'construction',
          worksite: data.worksite || 'Metro Expansion Project Pillar 142',
          employeeId: data.employeeId || `EMP-${fbUser.uid.slice(-4).toUpperCase()}`,
          baseHourlyRate: data.baseHourlyRate || 140,
        });
      } else {
        // Fallback profile if record wasn't created yet
        const defaultProfile: AppUser = {
          uid: fbUser.uid,
          email: fbUser.email || '',
          name: fbUser.displayName || 'FairShift User',
          role: hasEmployerAuth ? 'employer' : 'worker',
          industry: 'construction',
          worksite: 'Metro Expansion Project - Phase 4',
          employeeId: `EMP-${fbUser.uid.slice(-4).toUpperCase()}`,
          baseHourlyRate: 140,
        };
        await setDoc(userDocRef, {
          ...defaultProfile,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
        setUser(defaultProfile);
      }
    } catch (err) {
      console.error('Error loading user profile:', err);
      // Fallback in case of temporary offline/network delay
      setUser({
        uid: fbUser.uid,
        email: fbUser.email || '',
        name: fbUser.displayName || 'FairShift Worker',
        role: 'worker',
        industry: 'construction',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      await loadUserProfile(fbUser);
    });
    return () => unsubscribe();
  }, []);

  const signIn = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const cred = await signInWithEmailAndPassword(auth, email.trim(), pass);
      await loadUserProfile(cred.user);
    } catch (error) {
      setLoading(false);
      throw error;
    }
  };

  const signUpWorker = async ({
    email,
    pass,
    name,
    industry,
    worksite,
    employeeId,
    baseHourlyRate,
  }: {
    email: string;
    pass: string;
    name: string;
    industry: Industry;
    worksite: string;
    employeeId: string;
    baseHourlyRate: number;
  }) => {
    setLoading(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
      const uid = cred.user.uid;

      // Create strictly as a worker
      const profileData: AppUser = {
        uid,
        email: email.trim(),
        name: name.trim(),
        role: 'worker',
        industry,
        worksite: worksite.trim() || 'Metro Expansion Project',
        employeeId: employeeId.trim() || `EMP-${uid.slice(-4).toUpperCase()}`,
        baseHourlyRate: baseHourlyRate || 140,
        createdAt: new Date().toISOString(),
      };

      try {
        await setDoc(doc(db, 'users', uid), profileData);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
      }

      setUser(profileData);
      setIsEmployer(false);
    } finally {
      setLoading(false);
    }
  };

  const signUpEmployer = async ({
    email,
    pass,
    name,
    industry,
    companyName,
    authCode,
  }: {
    email: string;
    pass: string;
    name: string;
    industry: Industry;
    companyName: string;
    authCode: string;
  }) => {
    // Validate authorization code to prevent unauthorized elevation to Employer
    if (authCode.trim() !== EMPLOYER_AUTH_CODE) {
      throw new Error('Invalid Employer Authorization Code. Contact SRM ACM administration.');
    }

    setLoading(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
      const uid = cred.user.uid;

      // 1. Write trusted employer record in employers/{uid}
      try {
        await setDoc(doc(db, 'employers', uid), {
          uid,
          email: email.trim(),
          role: 'employer',
          companyName: companyName.trim(),
          authCode: authCode.trim(),
          authorizedAt: new Date().toISOString(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `employers/${uid}`);
      }

      // 2. Write user profile
      const profileData: AppUser = {
        uid,
        email: email.trim(),
        name: name.trim(),
        role: 'employer',
        industry,
        worksite: companyName.trim() || 'Central Workforce Command',
        createdAt: new Date().toISOString(),
      };

      try {
        await setDoc(doc(db, 'users', uid), profileData);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
      }

      setUser(profileData);
      setIsEmployer(true);
    } finally {
      setLoading(false);
    }
  };

  const logOut = async () => {
    setLoading(true);
    try {
      await signOut(auth);
      setUser(null);
      setIsEmployer(false);
    } finally {
      setLoading(false);
    }
  };

  const sendPasswordReset = async (email: string) => {
    await sendPasswordResetEmail(auth, email.trim());
  };

  // One-click demo sign-in helper
  const signInDemo = async (role: UserRole) => {
    const demoEmail = role === 'employer' ? 'employer@fairshift.demo' : 'worker@fairshift.demo';
    const demoPass = 'FairShift2026!';

    try {
      await signIn(demoEmail, demoPass);
    } catch {
      // If demo account doesn't exist yet, auto-provision it cleanly!
      if (role === 'employer') {
        await signUpEmployer({
          email: demoEmail,
          pass: demoPass,
          name: 'Supervisor Ananya Sharma',
          industry: 'construction',
          companyName: 'Metro Infrastructure & SRM Facilities',
          authCode: EMPLOYER_AUTH_CODE,
        });
      } else {
        await signUpWorker({
          email: demoEmail,
          pass: demoPass,
          name: 'Ramesh Patel',
          industry: 'construction',
          worksite: 'Metro Expansion Project - Phase 4 (Pillar 142)',
          employeeId: 'EMP-7809',
          baseHourlyRate: 140,
        });
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        user,
        loading,
        isEmployer,
        signIn,
        signUpWorker,
        signUpEmployer,
        logOut,
        sendPasswordReset,
        signInDemo,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
