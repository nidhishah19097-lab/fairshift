export type Language = 'en' | 'hi' | 'gu';

export type UserRole = 'worker' | 'employer';

export interface AppUser {
  uid: string;
  email: string;
  name: string;
  role: UserRole;
  industry: Industry;
  worksite?: string;
  employeeId?: string;
  baseHourlyRate?: number;
  createdAt?: string;
}

export type Industry = 'construction' | 'campus';

export interface ShiftRecord {
  id: string;
  workerId: string;
  workerName: string;
  industry: Industry;
  worksite: string;
  startTime: string; // ISO date string
  endTime: string | null; // null if active
  standardHours: number; // typically 8
  totalHours: number;
  overtimeHours: number;
  hourlyRate: number; // in INR ₹
  overtimeMultiplier: number; // e.g. 1.5 or 2.0
  overtimePay: number;
  estimatedPay: number;
  status: 'active' | 'completed';
  notes?: string;
}

export type HazardCategory =
  | 'fall_hazard'
  | 'machinery'
  | 'electrical'
  | 'chemical_dust'
  | 'heat_exhaustion'
  | 'inadequate_ppe'
  | 'harassment_wage'
  | 'ergonomic_lifting';

export type SeverityLevel = 'Low' | 'Medium' | 'High' | 'Critical';

export type ReportStatus = 'Open' | 'In Progress' | 'Resolved';

export interface SafetyReport {
  id: string; // e.g., SV-2026-104
  anonymousToken: string; // e.g., #ANON-9812
  timestamp: string; // ISO string
  industry: Industry;
  worksite: string;
  category: HazardCategory;
  severity: SeverityLevel;
  description: string;
  status: ReportStatus;
  adminNotes?: string;
  resolvedAt?: string;
  isDemoData: boolean;
}

export interface WorkerCertification {
  id: string;
  title: string;
  issuingAuthority: string;
  issueDate: string;
  expiryDate: string;
  level: string;
  verified: boolean;
}

export interface WorkerProfile {
  id: string;
  name: string;
  employeeId: string;
  role: string;
  industry: Industry;
  worksite: string;
  baseHourlyRate: number; // INR
  standardShiftHours: number; // Default 8
  overtimeMultiplier: number; // Default 1.5
  completedTrainingHours: number;
  certifications: WorkerCertification[];
}

export interface FatigueAlert {
  id: string;
  workerId: string;
  workerName: string;
  industry: Industry;
  currentHours: number;
  thresholdHours: number;
  level: 'normal' | 'caution' | 'warning' | 'critical';
  message: string;
  recommendation: string;
  lastRestHours: number;
}
