/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Language } from './types';
import { Header } from './components/Header';
import { WorkerPortal } from './components/worker/WorkerPortal';
import { EmployerPortal } from './components/admin/EmployerPortal';
import { SdgInfoModal } from './components/SdgInfoModal';
import { AuthModal } from './components/auth/AuthModal';
import { NotificationToast, ToastMessage } from './components/NotificationToast';
import { resetAllDemoData } from './utils/storage';
import { seedInitialFirestoreDataIfEmpty } from './utils/firestoreService';
import { translations } from './utils/translations';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ShieldCheck, HardHat, School, Database } from 'lucide-react';

function FairShiftApp() {
  const { user, isEmployer, loading } = useAuth();
  const [currentPortal, setCurrentPortal] = useState<'worker' | 'employer'>('worker');
  const [lang, setLang] = useState<Language>('en');
  const [isSdgModalOpen, setIsSdgModalOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [toast, setToast] = useState<ToastMessage | null>(null);

  const t = translations[lang];

  // Seed initial demonstration data to Firestore if not present
  useEffect(() => {
    seedInitialFirestoreDataIfEmpty();
  }, []);

  // Sync dashboard with authenticated user role
  useEffect(() => {
    if (user) {
      if (isEmployer) {
        setCurrentPortal('employer');
      } else {
        setCurrentPortal('worker');
      }
    }
  }, [user, isEmployer]);

  const handleResetData = () => {
    resetAllDemoData();
    setToast({
      id: Date.now().toString(),
      type: 'info',
      message: t.dataResetSuccess,
    });
  };

  const handleNotify = (newToast: ToastMessage) => {
    setToast(newToast);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-blue-100 selection:text-blue-900">
      {/* Top Bar Header */}
      <Header
        currentPortal={currentPortal}
        onPortalChange={setCurrentPortal}
        lang={lang}
        onLanguageChange={setLang}
        onResetData={handleResetData}
        onOpenSdgModal={() => setIsSdgModalOpen(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 md:py-8">
        {loading ? (
          <div className="py-24 text-center">
            <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs text-slate-500 font-semibold">
              Connecting to Firebase Authentication &amp; Firestore...
            </p>
          </div>
        ) : currentPortal === 'worker' ? (
          <WorkerPortal lang={lang} onNotify={handleNotify} />
        ) : (
          <EmployerPortal
            lang={lang}
            onNotify={handleNotify}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
          />
        )}
      </main>

      {/* Clean Accessible Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            <span className="font-semibold text-slate-800">FairShift</span>
            <span aria-hidden="true">·</span>
            <span>Work Should Be Fair</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-400">Firebase Integrated</span>
          </div>

          <div className="flex items-center gap-4 flex-wrap justify-center">
            <button
              onClick={() => setIsSdgModalOpen(true)}
              className="hover:text-blue-600 transition-colors font-medium flex items-center gap-1"
            >
              <span>UN SDG 8 Directives</span>
            </button>
            <span aria-hidden="true" className="text-slate-300">|</span>
            <span className="flex items-center gap-1 text-slate-600">
              <HardHat className="w-3.5 h-3.5 text-amber-600" />
              <span>Construction</span>
            </span>
            <span aria-hidden="true" className="text-slate-300">&amp;</span>
            <span className="flex items-center gap-1 text-slate-600">
              <School className="w-3.5 h-3.5 text-indigo-600" />
              <span>Campus Facilities</span>
            </span>
            <span aria-hidden="true" className="text-slate-300">|</span>
            <span className="text-slate-400">SRM ACM Chapter</span>
          </div>
        </div>
      </footer>

      {/* Toast Feedback */}
      <NotificationToast toast={toast} onClose={() => setToast(null)} />

      {/* UN SDG 8 Modal */}
      <SdgInfoModal
        isOpen={isSdgModalOpen}
        onClose={() => setIsSdgModalOpen(false)}
        lang={lang}
      />

      {/* Firebase Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        lang={lang}
        onNotify={handleNotify}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <FairShiftApp />
    </AuthProvider>
  );
}
