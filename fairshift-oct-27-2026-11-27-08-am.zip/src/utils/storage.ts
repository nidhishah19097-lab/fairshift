import {
  Industry,
  SafetyReport,
  ShiftRecord,
  WorkerProfile,
} from '../types';

const STORAGE_KEYS = {
  SHIFTS: 'fairshift_shifts_v1',
  SAFETY_REPORTS: 'fairshift_safety_reports_v1',
  ACTIVE_SHIFT: 'fairshift_active_shift_v1',
  CURRENT_WORKER: 'fairshift_current_worker_v1',
  CONFIG: 'fairshift_config_v1',
};

export const DEFAULT_CURRENT_WORKER: WorkerProfile = {
  id: 'WKR-CON-401',
  name: 'Ramesh Patel',
  employeeId: 'EMP-7809',
  role: 'Senior Rigging & Scaffolding Lead',
  industry: 'construction',
  worksite: 'Metro Expansion Project - Phase 4 (Pillar 142)',
  baseHourlyRate: 140, // ₹140/hr
  standardShiftHours: 8.0,
  overtimeMultiplier: 1.5,
  completedTrainingHours: 48,
  certifications: [
    {
      id: 'CERT-SCAF-01',
      title: 'Scaffold Rigging & Fall Arrest Level 2',
      issuingAuthority: 'National Skill Development Council (NSDC)',
      issueDate: '2025-08-14',
      expiryDate: '2027-08-14',
      level: 'Advanced',
      verified: true,
    },
    {
      id: 'CERT-ELECT-02',
      title: 'Site Electrical Safety & Lockout/Tagout (LOTO)',
      issuingAuthority: 'Safety First India Institute',
      issueDate: '2026-01-10',
      expiryDate: '2028-01-10',
      level: 'Certified',
      verified: true,
    },
    {
      id: 'CERT-FAID-03',
      title: 'First Aid & Heat-Stroke Response',
      issuingAuthority: 'Indian Red Cross Society',
      issueDate: '2025-11-20',
      expiryDate: '2027-11-20',
      level: 'Core',
      verified: true,
    },
  ],
};

export const INITIAL_SHIFTS: ShiftRecord[] = [
  {
    id: 'SH-2026-101',
    workerId: 'WKR-CON-401',
    workerName: 'Ramesh Patel',
    industry: 'construction',
    worksite: 'Metro Line Pillar 142 - Pier Cap Concrete',
    startTime: new Date(Date.now() - 36 * 3600 * 1000).toISOString(),
    endTime: new Date(Date.now() - 25.5 * 3600 * 1000).toISOString(),
    standardHours: 8.0,
    totalHours: 10.5,
    overtimeHours: 2.5,
    hourlyRate: 140,
    overtimeMultiplier: 1.5,
    overtimePay: 525, // 2.5 * 140 * 1.5
    estimatedPay: 1645, // (8 * 140) + 525
    status: 'completed',
    notes: 'Extended pour shift due to transit mixer queue',
  },
  {
    id: 'SH-2026-102',
    workerId: 'WKR-CON-402',
    workerName: 'Vikram Singh',
    industry: 'construction',
    worksite: 'Metro Line Pillar 144 - Rebar Tying',
    startTime: new Date(Date.now() - 30 * 3600 * 1000).toISOString(),
    endTime: new Date(Date.now() - 21 * 3600 * 1000).toISOString(),
    standardHours: 8.0,
    totalHours: 9.0,
    overtimeHours: 1.0,
    hourlyRate: 130,
    overtimeMultiplier: 1.5,
    overtimePay: 195,
    estimatedPay: 1235,
    status: 'completed',
  },
  {
    id: 'SH-2026-103',
    workerId: 'WKR-CMP-201',
    workerName: 'Sunita Devi',
    industry: 'campus',
    worksite: 'SRM Campus - Central HVAC & Substation 3',
    startTime: new Date(Date.now() - 28 * 3600 * 1000).toISOString(),
    endTime: new Date(Date.now() - 20 * 3600 * 1000).toISOString(),
    standardHours: 8.0,
    totalHours: 8.0,
    overtimeHours: 0.0,
    hourlyRate: 125,
    overtimeMultiplier: 1.5,
    overtimePay: 0,
    estimatedPay: 1000,
    status: 'completed',
  },
  {
    id: 'SH-2026-104',
    workerId: 'WKR-CMP-202',
    workerName: 'Mohan Kumar',
    industry: 'campus',
    worksite: 'SRM Tech Park Labs - Sanitation & Waste Treatment',
    startTime: new Date(Date.now() - 26 * 3600 * 1000).toISOString(),
    endTime: new Date(Date.now() - 15 * 3600 * 1000).toISOString(),
    standardHours: 8.0,
    totalHours: 11.0,
    overtimeHours: 3.0,
    hourlyRate: 120,
    overtimeMultiplier: 1.5,
    overtimePay: 540, // 3 * 120 * 1.5
    estimatedPay: 1500,
    status: 'completed',
    notes: 'Emergency water main pipe burst repairs during night',
  },
  {
    id: 'SH-2026-105',
    workerId: 'WKR-CON-403',
    workerName: 'Farhan Ansari',
    industry: 'construction',
    worksite: 'Metro Elevated Viaduct Zone B',
    startTime: new Date(Date.now() - 9.5 * 3600 * 1000).toISOString(),
    endTime: null, // Still active
    standardHours: 8.0,
    totalHours: 9.5,
    overtimeHours: 1.5,
    hourlyRate: 135,
    overtimeMultiplier: 1.5,
    overtimePay: 304,
    estimatedPay: 1384,
    status: 'active',
  },
  {
    id: 'SH-2026-106',
    workerId: 'WKR-CMP-203',
    workerName: 'Priya Narayanan',
    industry: 'campus',
    worksite: 'SRM University - Bio-Chemical Waste Store',
    startTime: new Date(Date.now() - 6.2 * 3600 * 1000).toISOString(),
    endTime: null, // Still active
    standardHours: 8.0,
    totalHours: 6.2,
    overtimeHours: 0.0,
    hourlyRate: 130,
    overtimeMultiplier: 1.5,
    overtimePay: 0,
    estimatedPay: 806,
    status: 'active',
  },
];

export const INITIAL_SAFETY_REPORTS: SafetyReport[] = [
  {
    id: 'SV-2026-081',
    anonymousToken: '#ANON-7712',
    timestamp: new Date(Date.now() - 14 * 3600 * 1000).toISOString(),
    industry: 'construction',
    worksite: 'Metro Station Pier 142 - Level 3 Scaffolding',
    category: 'fall_hazard',
    severity: 'Critical',
    description:
      'Perimeter safety catch net is loose and missing two anchor hooks on the south-facing scaffold. High risk of debris fall onto ground workers.',
    status: 'In Progress',
    adminNotes:
      'Safety marshals dispatched with replacement carabiners. Work temporarily halted at height.',
    isDemoData: true,
  },
  {
    id: 'SV-2026-082',
    anonymousToken: '#ANON-9043',
    timestamp: new Date(Date.now() - 22 * 3600 * 1000).toISOString(),
    industry: 'construction',
    worksite: 'Batching Plant Rebar Yard',
    category: 'inadequate_ppe',
    severity: 'Medium',
    description:
      'Batching yard workers given damaged fabric gloves instead of heavy-duty cut-resistant nitrile gloves while handling sharp steel rebar bundles.',
    status: 'Open',
    adminNotes: '',
    isDemoData: true,
  },
  {
    id: 'SV-2026-083',
    anonymousToken: '#ANON-3321',
    timestamp: new Date(Date.now() - 8 * 3600 * 1000).toISOString(),
    industry: 'campus',
    worksite: 'SRM Chemistry Research Block - Fume Exhaust Shaft',
    category: 'chemical_dust',
    severity: 'High',
    description:
      'Exhaust vent duct on the 4th floor sanitation shaft is vibrating loudly and venting strong solvent fumes into the housekeeping service corridor.',
    status: 'Open',
    adminNotes: 'Notified SRM estate maintenance team for air flow damper inspection.',
    isDemoData: true,
  },
  {
    id: 'SV-2026-084',
    anonymousToken: '#ANON-1156',
    timestamp: new Date(Date.now() - 48 * 3600 * 1000).toISOString(),
    industry: 'campus',
    worksite: 'SRM Main Sports Complex - Substation Trench',
    category: 'electrical',
    severity: 'Critical',
    description:
      'Submersible water pump cable has cracked insulation sitting directly in pooled storm runoff water near the electrical distribution panel.',
    status: 'Resolved',
    adminNotes: 'Cable replaced with armored heavy-duty waterproof conduit. Pump re-earthed.',
    resolvedAt: new Date(Date.now() - 20 * 3600 * 1000).toISOString(),
    isDemoData: true,
  },
  {
    id: 'SV-2026-085',
    anonymousToken: '#ANON-5589',
    timestamp: new Date(Date.now() - 32 * 3600 * 1000).toISOString(),
    industry: 'construction',
    worksite: 'Pier 140 Batching Truck Unloading Zone',
    category: 'heat_exhaustion',
    severity: 'High',
    description:
      'Drinking water tanker was empty for 4 hours during 38°C peak afternoon sun. Two cement unloaders felt severe dizzy spells and nausea.',
    status: 'Resolved',
    adminNotes: 'Mandatory secondary water chiller installed with electrolyte ORS sachets provided on site.',
    resolvedAt: new Date(Date.now() - 10 * 3600 * 1000).toISOString(),
    isDemoData: true,
  },
];

// Helper to notify listeners across the app
export const emitStorageUpdate = () => {
  window.dispatchEvent(new Event('fairshift_storage_update'));
};

export const getStoredShifts = (): ShiftRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SHIFTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SHIFTS, JSON.stringify(INITIAL_SHIFTS));
      return INITIAL_SHIFTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_SHIFTS;
  }
};

export const saveShifts = (shifts: ShiftRecord[]) => {
  localStorage.setItem(STORAGE_KEYS.SHIFTS, JSON.stringify(shifts));
  emitStorageUpdate();
};

export const getStoredSafetyReports = (): SafetyReport[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SAFETY_REPORTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.SAFETY_REPORTS, JSON.stringify(INITIAL_SAFETY_REPORTS));
      return INITIAL_SAFETY_REPORTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_SAFETY_REPORTS;
  }
};

export const saveSafetyReports = (reports: SafetyReport[]) => {
  localStorage.setItem(STORAGE_KEYS.SAFETY_REPORTS, JSON.stringify(reports));
  emitStorageUpdate();
};

export const getActiveShift = (): ShiftRecord | null => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACTIVE_SHIFT);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

export const saveActiveShift = (shift: ShiftRecord | null) => {
  if (shift) {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_SHIFT, JSON.stringify(shift));
  } else {
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_SHIFT);
  }
  emitStorageUpdate();
};

export const getCurrentWorker = (): WorkerProfile => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_WORKER);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_WORKER, JSON.stringify(DEFAULT_CURRENT_WORKER));
      return DEFAULT_CURRENT_WORKER;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_CURRENT_WORKER;
  }
};

export const saveCurrentWorker = (worker: WorkerProfile) => {
  localStorage.setItem(STORAGE_KEYS.CURRENT_WORKER, JSON.stringify(worker));
  emitStorageUpdate();
};

export const resetAllDemoData = () => {
  localStorage.setItem(STORAGE_KEYS.SHIFTS, JSON.stringify(INITIAL_SHIFTS));
  localStorage.setItem(STORAGE_KEYS.SAFETY_REPORTS, JSON.stringify(INITIAL_SAFETY_REPORTS));
  localStorage.removeItem(STORAGE_KEYS.ACTIVE_SHIFT);
  localStorage.setItem(STORAGE_KEYS.CURRENT_WORKER, JSON.stringify(DEFAULT_CURRENT_WORKER));
  emitStorageUpdate();
};
