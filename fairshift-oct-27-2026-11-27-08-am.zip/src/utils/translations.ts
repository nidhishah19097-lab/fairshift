import { Language } from '../types';

export interface Translations {
  appName: string;
  tagline: string;
  portalWorker: string;
  portalEmployer: string;
  demoModeBadge: string;
  demoNotice: string;
  resetDemoData: string;
  dataResetSuccess: string;
  sdgTitle: string;
  sdgTag: string;

  // Tabs
  tabAttendance: string;
  tabWage: string;
  tabSafeVoice: string;
  tabFatigue: string;
  tabPassport: string;

  // Attendance
  attendanceTitle: string;
  attendanceSubtitle: string;
  startShift: string;
  endShift: string;
  shiftActive: string;
  shiftEnded: string;
  shiftTimer: string;
  standardShift: string;
  hoursWorked: string;
  overtimeHours: string;
  worksiteLabel: string;
  shiftHistory: string;
  noShiftsYet: string;
  shiftStartedSuccess: string;
  shiftEndedSuccess: string;
  shiftAlreadyActiveError: string;
  shiftNotStartedError: string;
  activeShiftBanner: string;
  liveStatus: string;
  clockInTime: string;

  // Wage Transparency
  wageTitle: string;
  wageSubtitle: string;
  basicHourlyRate: string;
  regularHoursWorked: string;
  regularPay: string;
  overtimeMultiplier: string;
  overtimePay: string;
  statutoryDeductions: string;
  netEstimatedPay: string;
  grossPay: string;
  wageDisclaimerTitle: string;
  wageDisclaimerText: string;
  paySlipBreakdown: string;
  inrCurrency: string;
  hourlyRateSuffix: string;

  // SafeVoice
  safeVoiceTitle: string;
  safeVoiceSubtitle: string;
  safeVoiceShieldNotice: string;
  reportHazardBtn: string;
  categoryLabel: string;
  workplaceLabel: string;
  severityLabel: string;
  descriptionLabel: string;
  descriptionPlaceholder: string;
  submitReport: string;
  reportSubmittedSuccess: string;
  yourAnonymousToken: string;
  tokenInstruction: string;
  recentSubmittedReports: string;
  noReportsWorker: string;
  privacyBoundaryNote: string;

  // FatigueGuard
  fatigueTitle: string;
  fatigueSubtitle: string;
  fatigueLevel: string;
  fatigueNormal: string;
  fatigueCaution: string;
  fatigueWarning: string;
  fatigueCritical: string;
  consecutiveHours: string;
  recommendedRest: string;
  ruleBasedDisclaimer: string;
  hydrationAlert: string;
  safeLimitBadge: string;

  // Skill Passport
  passportTitle: string;
  passportSubtitle: string;
  workerIdLabel: string;
  verifiedSkills: string;
  trainingHours: string;
  certificationsTitle: string;
  verifiedBadge: string;
  downloadCredential: string;

  // Employer Portal
  employerTitle: string;
  employerSubtitle: string;
  filterIndustry: string;
  allIndustries: string;
  industryConstruction: string;
  industryCampus: string;
  kpiTotalWorkers: string;
  kpiOnShift: string;
  kpiOvertimeAlerts: string;
  kpiOpenHazards: string;
  kpiFatigueWarnings: string;
  comparisonTitle: string;
  comparisonSubtitle: string;
  workforceRosterTitle: string;
  incidentConsoleTitle: string;
  statusLabel: string;
  actionUpdateStatus: string;
  notesPlaceholder: string;
  saveChanges: string;
  filterBySeverity: string;
  noIncidentsFound: string;
  markedAsResolved: string;
  statusOpen: string;
  statusInProgress: string;
  statusResolved: string;
  supervisorGuidance: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appName: 'FairShift',
    tagline: 'Work Should Be Fair',
    portalWorker: 'Worker Portal',
    portalEmployer: 'Employer Portal',
    demoModeBadge: 'Prompt Wars 2026 Demo',
    demoNotice: 'Demonstration prototype with sample data. Local data stored in browser.',
    resetDemoData: 'Reset Demo Data',
    dataResetSuccess: 'Demonstration records reset to default state.',
    sdgTitle: 'UN SDG 8: Decent Work & Economic Growth',
    sdgTag: 'Target 8.8: Safe & Secure Working Environments',

    tabAttendance: 'Smart Attendance',
    tabWage: 'Wage Transparency',
    tabSafeVoice: 'SafeVoice (Anonymous)',
    tabFatigue: 'FatigueGuard',
    tabPassport: 'Skill Passport',

    attendanceTitle: 'Smart Shift Attendance',
    attendanceSubtitle: 'Accurate timestamp recording and transparent overtime calculation',
    startShift: 'Start Shift (Clock In)',
    endShift: 'End Shift (Clock Out)',
    shiftActive: 'Active Shift in Progress',
    shiftEnded: 'Shift Completed',
    shiftTimer: 'Shift Duration',
    standardShift: 'Standard Shift: 8.0 hrs',
    hoursWorked: 'Hours Worked',
    overtimeHours: 'Overtime Hours',
    worksiteLabel: 'Worksite / Facility',
    shiftHistory: 'Attendance & Overtime Log',
    noShiftsYet: 'No shifts recorded yet for today.',
    shiftStartedSuccess: 'Shift started successfully at',
    shiftEndedSuccess: 'Shift concluded. Total logged time:',
    shiftAlreadyActiveError: 'You already have an active shift in progress.',
    shiftNotStartedError: 'No active shift to conclude. Please start a shift first.',
    activeShiftBanner: 'You are currently on active shift duty at',
    liveStatus: 'Active Now',
    clockInTime: 'Clock In Time',

    wageTitle: 'Wage Transparency Calculator',
    wageSubtitle: 'Clear, verifiable itemized earnings based on recorded and projected hours',
    basicHourlyRate: 'Base Hourly Rate',
    regularHoursWorked: 'Regular Shift Hours',
    regularPay: 'Regular Basic Pay',
    overtimeMultiplier: 'Overtime Pay Multiplier (e.g., 1.5x / 2.0x)',
    overtimePay: 'Calculated Overtime Pay',
    statutoryDeductions: 'Statutory / Canteen Deductions',
    netEstimatedPay: 'Estimated Net Take-Home Pay',
    grossPay: 'Gross Estimated Earnings',
    wageDisclaimerTitle: 'Statutory Wage Disclaimer',
    wageDisclaimerText:
      'Calculations are rule-based estimates provided for verification and transparency. Actual payroll complies with applicable state minimum wages and statutory deductions (PF/ESI).',
    paySlipBreakdown: 'Itemized Wage Statement',
    inrCurrency: '₹',
    hourlyRateSuffix: '/ hr',

    safeVoiceTitle: 'SafeVoice Anonymous Hazard Reporting',
    safeVoiceSubtitle: 'Report unsafe conditions, machinery issues, or exploitation without fear of retaliation',
    safeVoiceShieldNotice:
      'Identity Protection Active: Your name and employee ID are never attached or visible to supervisors.',
    reportHazardBtn: 'File Anonymous Hazard Report',
    categoryLabel: 'Hazard Category',
    workplaceLabel: 'Worksite / Department',
    severityLabel: 'Urgency & Severity Level',
    descriptionLabel: 'Detailed Hazard Description',
    descriptionPlaceholder:
      'Describe what happened or what condition needs immediate attention (e.g., missing safety net on 3rd floor scaffolding, exposed 440V wire in electrical duct)...',
    submitReport: 'Submit Anonymous Report',
    reportSubmittedSuccess: 'Hazard report securely filed! Reference Token:',
    yourAnonymousToken: 'Your Anonymous Receipt Token',
    tokenInstruction: 'Save this token to anonymously track progress in the incident board without disclosing who you are.',
    recentSubmittedReports: 'My Anonymous Submissions (This Device)',
    noReportsWorker: 'No hazard reports submitted yet.',
    privacyBoundaryNote:
      'Note: This hackathon prototype stores data locally and demonstrates strict identity separation; production deployments connect to zero-knowledge audit logs.',

    fatigueTitle: 'FatigueGuard Rest & Safety Monitor',
    fatigueSubtitle: 'Proactive fatigue risk alerts to prevent workplace accidents and exhaustion',
    fatigueLevel: 'Current Fatigue Risk Level',
    fatigueNormal: 'Optimal / Safe Hours',
    fatigueCaution: 'Moderate Fatigue Caution',
    fatigueWarning: 'High Overtime Alert (>8 hrs)',
    fatigueCritical: 'Critical Fatigue Risk (>10 hrs)',
    consecutiveHours: 'Consecutive Duty Duration',
    recommendedRest: 'Mandatory Rest Recommendation',
    ruleBasedDisclaimer:
      'Rule-Based Safety Indicator: These alerts are calculated from logged shift thresholds and do not constitute clinical or medical advice.',
    hydrationAlert: 'Hydration & Rest Break Reminder: Take 10 minutes shade break every 2 hours in high heat conditions.',
    safeLimitBadge: 'Compliant with Labour Standard Thresholds',

    passportTitle: 'Digital Skill Passport',
    passportSubtitle: 'Portable, verified safety certifications and workforce experience record',
    workerIdLabel: 'Worker Identity / Card ID',
    verifiedSkills: 'Verified Technical Competencies',
    trainingHours: 'Verified Safety Training Logged',
    certificationsTitle: 'Issued Safety Certifications',
    verifiedBadge: 'Verified Issuer',
    downloadCredential: 'View Credential Pass',

    employerTitle: 'Workforce Operations & Safety Command',
    employerSubtitle: 'Real-time visibility into shift compliance, overtime fairness, and site safety',
    filterIndustry: 'Filter by Industry Sector',
    allIndustries: 'All Sectors (Cross-Industry)',
    industryConstruction: 'Construction Sites',
    industryCampus: 'College & Campus Facilities',
    kpiTotalWorkers: 'Active Demonstration Workers',
    kpiOnShift: 'Currently On Active Shift',
    kpiOvertimeAlerts: 'Active Overtime Alerts',
    kpiOpenHazards: 'Open Safety Reports',
    kpiFatigueWarnings: 'Elevated Fatigue Warnings',
    comparisonTitle: 'Sector Comparison: Attendance & Overtime Exposure',
    comparisonSubtitle: 'Comparative analysis between Construction Sites and Campus Facilities',
    workforceRosterTitle: 'Live Shift Attendance Roster',
    incidentConsoleTitle: 'SafeVoice Hazard Incident Console (Identity Shielded)',
    statusLabel: 'Status',
    actionUpdateStatus: 'Update Incident Status',
    notesPlaceholder: 'Add supervisor remediation notes (e.g. Scaffolding repaired on 26 Oct)...',
    saveChanges: 'Save Status Update',
    filterBySeverity: 'Filter Severity',
    noIncidentsFound: 'No safety incidents match current filter criteria.',
    markedAsResolved: 'Incident marked as Resolved.',
    statusOpen: 'Open',
    statusInProgress: 'In Progress',
    statusResolved: 'Resolved',
    supervisorGuidance: 'Supervisor Action Required: Review high severity hazards within 2 hours.',
  },
  hi: {
    appName: 'फेयरशिफ्ट (FairShift)',
    tagline: 'काम निष्पक्ष और पारदर्शी होना चाहिए',
    portalWorker: 'श्रमिक पोर्टल',
    portalEmployer: 'नियोक्ता / सुपरवाइजर पोर्टल',
    demoModeBadge: 'प्रॉम्प्ट वॉर्स 2026 डेमो',
    demoNotice: 'नमूना डेटा के साथ प्रदर्शन प्रोटोटाइप। स्थानीय डेटा ब्राउज़र में संग्रहीत है।',
    resetDemoData: 'डेमो डेटा रीसेट करें',
    dataResetSuccess: 'प्रदर्शन रिकॉर्ड मूल स्थिति में रीसेट हो गए हैं।',
    sdgTitle: 'संयुक्त राष्ट्र SDG 8: मर्यादित कार्य और आर्थिक विकास',
    sdgTag: 'लक्ष्य 8.8: सुरक्षित और संरक्षित कार्य वातावरण',

    tabAttendance: 'स्मार्ट उपस्थिति',
    tabWage: 'वेतन पारदर्शिता',
    tabSafeVoice: 'सेफवॉइस (गुमनाम रिपोर्टिंग)',
    tabFatigue: 'थकान सुरक्षा (FatigueGuard)',
    tabPassport: 'स्किल पासपोर्ट',

    attendanceTitle: 'स्मार्ट शिफ्ट उपस्थिति',
    attendanceSubtitle: 'सटीक टाइमस्टैम्प रिकॉर्डिंग और पारदर्शी ओवरटाइम गणना',
    startShift: 'शिफ्ट शुरू करें (Clock In)',
    endShift: 'शिफ्ट समाप्त करें (Clock Out)',
    shiftActive: 'सक्रिय शिफ्ट जारी है',
    shiftEnded: 'शिफ्ट पूरी हुई',
    shiftTimer: 'शिफ्ट की अवधि',
    standardShift: 'मानक शिफ्ट: 8.0 घंटे',
    hoursWorked: 'कुल काम के घंटे',
    overtimeHours: 'ओवरटाइम घंटे',
    worksiteLabel: 'कार्यस्थल / परिसर',
    shiftHistory: 'उपस्थिति और ओवरटाइम इतिहास',
    noShiftsYet: 'आज के लिए अभी तक कोई शिफ्ट दर्ज नहीं है।',
    shiftStartedSuccess: 'शिफ्ट सफलतापूर्वक शुरू हुई समय:',
    shiftEndedSuccess: 'शिफ्ट समाप्त हुई। कुल दर्ज समय:',
    shiftAlreadyActiveError: 'आपकी पहले से ही एक शिफ्ट चालू है।',
    shiftNotStartedError: 'समाप्त करने के लिए कोई सक्रिय शिफ्ट नहीं है। पहले शिफ्ट शुरू करें।',
    activeShiftBanner: 'आप वर्तमान में कार्यस्थल पर सक्रिय ड्यूटी पर हैं:',
    liveStatus: 'वर्तमान में कार्यरत',
    clockInTime: 'शुरुआत का समय',

    wageTitle: 'वेतन पारदर्शिता कैलकुलेटर',
    wageSubtitle: 'दर्ज घंटों और ओवरटाइम पर आधारित पारदर्शी और सटीक वेतन अनुमान',
    basicHourlyRate: 'मूल प्रति घंटा दर',
    regularHoursWorked: 'नियमित काम के घंटे',
    regularPay: 'मूल नियमित वेतन',
    overtimeMultiplier: 'ओवरटाइम गुणक (जैसे 1.5x / 2.0x)',
    overtimePay: 'ओवरटाइम का अतिरिक्त भुगतान',
    statutoryDeductions: 'वैधानिक / कैंटीन कटौती',
    netEstimatedPay: 'अनुमानित शुद्ध इन-हैंड वेतन',
    grossPay: 'कुल अनुमानित आय',
    wageDisclaimerTitle: 'वैधानिक वेतन सूचना',
    wageDisclaimerText:
      'यह गणना नियमों पर आधारित अनुमान है। वास्तविक भुगतान श्रम कानूनों और सरकारी न्यूनतम वेतन के अनुसार देय होता है।',
    paySlipBreakdown: 'वेतन विवरण (Pay Slip Breakdown)',
    inrCurrency: '₹',
    hourlyRateSuffix: '/ घंटा',

    safeVoiceTitle: 'सेफवॉइस गुमनाम सुरक्षा रिपोर्टिंग',
    safeVoiceSubtitle: 'बिना किसी डर के कार्यस्थल के खतरों और समस्याओं की रिपोर्ट करें',
    safeVoiceShieldNotice: 'पहचान सुरक्षा सक्रिय: आपका नाम या आईडी सुपरवाइजर को कभी नहीं दिखाया जाता है।',
    reportHazardBtn: 'गुमनाम खतरा रिपोर्ट दर्ज करें',
    categoryLabel: 'खतरे की श्रेणी',
    workplaceLabel: 'कार्यस्थल / विभाग',
    severityLabel: 'गंभीरता का स्तर',
    descriptionLabel: 'खतरे का विस्तृत विवरण',
    descriptionPlaceholder:
      'समस्या का विवरण दें (जैसे तीसरी मंजिल पर सुरक्षा जाल गायब है, खुला बिजली का तार है, आदि)...',
    submitReport: 'गुमनाम रिपोर्ट सबमिट करें',
    reportSubmittedSuccess: 'सुरक्षा रिपोर्ट दर्ज की गई! संदर्भ टोकन:',
    yourAnonymousToken: 'आपका गुमनाम रसीद टोकन',
    tokenInstruction: 'अपनी पहचान उजागर किए बिना स्थिति जांचने के लिए इस टोकन को सुरक्षित रखें।',
    recentSubmittedReports: 'इस डिवाइस से सबमिट की गई रिपोर्ट',
    noReportsWorker: 'अभी तक कोई रिपोर्ट सबमिट नहीं की गई है।',
    privacyBoundaryNote:
      'नोट: यह हैकथॉन प्रोटोटाइप डेटा को सुरक्षित रखता है और पूरी गुमनामी सुनिश्चित करता है।',

    fatigueTitle: 'थकान सुरक्षा मॉनिटर (FatigueGuard)',
    fatigueSubtitle: 'दुर्घटनाओं और अत्यधिक थकान से बचाव के लिए पूर्व चेतावनी प्रणाली',
    fatigueLevel: 'वर्तमान थकान जोखिम स्तर',
    fatigueNormal: 'सामान्य / सुरक्षित कार्य घंटे',
    fatigueCaution: 'सावधानी का स्तर',
    fatigueWarning: 'उच्च ओवरटाइम चेतावनी (>8 घंटे)',
    fatigueCritical: 'गंभीर थकान जोखिम (>10 घंटे)',
    consecutiveHours: 'लगातार ड्यूटी के घंटे',
    recommendedRest: 'अनिवार्य विश्राम की सिफारिश',
    ruleBasedDisclaimer:
      'नियम-आधारित सुरक्षा संकेतक: ये चेतावनियां कार्य घंटों के नियमों पर आधारित हैं, चिकित्सकीय निदान नहीं हैं।',
    hydrationAlert: 'पानी और आराम का अनुस्मारक: अधिक गर्मी में हर 2 घंटे में 10 मिनट छाया में आराम करें।',
    safeLimitBadge: 'श्रम मानक नियमों के अनुरूप',

    passportTitle: 'डिजिटल स्किल पासपोर्ट',
    passportSubtitle: 'प्रमाणित सुरक्षा प्रमाणपत्र और कार्य अनुभव का डिजिटल रिकॉर्ड',
    workerIdLabel: 'श्रमिक पहचान आईडी',
    verifiedSkills: 'सत्यापित तकनीकी कौशल',
    trainingHours: 'सुरक्षा प्रशिक्षण के घंटे',
    certificationsTitle: 'जारी किए गए सुरक्षा प्रमाणपत्र',
    verifiedBadge: 'सत्यापित जारीकर्ता',
    downloadCredential: 'प्रमाणपत्र कार्ड देखें',

    employerTitle: 'कार्यबल प्रबंधन और सुरक्षा कमान',
    employerSubtitle: 'शिफ्ट अनुपालन, निष्पक्ष ओवरटाइम और स्थल सुरक्षा की वास्तविक समय जानकारी',
    filterIndustry: 'उद्योग क्षेत्र चुनें',
    allIndustries: 'सभी क्षेत्र (All Sectors)',
    industryConstruction: 'निर्माण स्थल (Construction)',
    industryCampus: 'कॉलेज और परिसर सुविधाएं (Campus)',
    kpiTotalWorkers: 'कुल सक्रिय डेमो श्रमिक',
    kpiOnShift: 'वर्तमान में शिफ्ट पर मौजूद',
    kpiOvertimeAlerts: 'ओवरटाइम चेतावनियां',
    kpiOpenHazards: 'लंबित सुरक्षा रिपोर्ट',
    kpiFatigueWarnings: 'अत्यधिक थकान चेतावनियां',
    comparisonTitle: 'क्षेत्रवार तुलना: उपस्थिति और ओवरटाइम जोखिम',
    comparisonSubtitle: 'निर्माण स्थल बनाम कॉलेज परिसर सुविधाओं का तुलनात्मक विश्लेषण',
    workforceRosterTitle: 'लाइव शिफ्ट उपस्थिति रोस्टर',
    incidentConsoleTitle: 'सेफवॉइस घटना निवारण कंसोल (पहचान गोपनीय)',
    statusLabel: 'स्थिति',
    actionUpdateStatus: 'घटना की स्थिति अपडेट करें',
    notesPlaceholder: 'सुपरवाइजर निवारण नोट जोड़ें (जैसे मरम्मत पूरी हो गई)...',
    saveChanges: 'अपडेट सहेजें',
    filterBySeverity: 'गंभीरता के अनुसार फ़िल्टर करें',
    noIncidentsFound: 'इस फ़िल्टर में कोई घटना नहीं मिली।',
    markedAsResolved: 'घटना का समाधान कर दिया गया है।',
    statusOpen: 'खुला (Open)',
    statusInProgress: 'प्रक्रिया में (In Progress)',
    statusResolved: 'हल किया गया (Resolved)',
    supervisorGuidance: 'सुपरवाइजर कार्रवाई: 2 घंटे के भीतर उच्च गंभीरता वाले खतरों की जांच करें।',
  },
  gu: {
    appName: 'ફેરશિફ્ટ (FairShift)',
    tagline: 'કામ ન્યાયી અને પારદર્શક હોવું જોઈએ',
    portalWorker: 'શ્રમિક પોર્ટલ',
    portalEmployer: 'નિયોજક / સુપરવાઇઝર પોર્ટલ',
    demoModeBadge: 'પ્રોમ્પ્ટ વોર્સ 2026 ડેમો',
    demoNotice: 'નમૂના ડેટા સાથે પ્રદર્શન પ્રોટોટાઇપ. લોકલ ડેટા બ્રાઉઝરમાં સાચવવામાં આવે છે.',
    resetDemoData: 'ડેમો ડેટા રીસેટ કરો',
    dataResetSuccess: 'ડેમો ડેટા મૂળ સ્થિતિમાં ફરીથી ગોઠવાયો છે.',
    sdgTitle: 'યુએન SDG 8: ગૌરવપૂર્ણ કાર્ય અને આર્થિક વિકાસ',
    sdgTag: 'લક્ષ્ય 8.8: સુરક્ષિત અને સલામત કાર્ય વાતાવરણ',

    tabAttendance: 'સ્માર્ટ હાજરી',
    tabWage: 'વેતન પારદર્શિતા',
    tabSafeVoice: 'સેફવોઇસ (ગુપ્ત રિપોર્ટિંગ)',
    tabFatigue: 'થાક સુરક્ષા (FatigueGuard)',
    tabPassport: 'સ્કિલ પાસપોર્ટ',

    attendanceTitle: 'સ્માર્ટ શિફ્ટ હાજરી',
    attendanceSubtitle: 'ચોક્કસ સમય નોંધણી અને પારદર્શક ઓવરટાઇમ ગણતરી',
    startShift: 'શિફ્ટ શરૂ કરો (Clock In)',
    endShift: 'શિફ્ટ સમાપ્ત કરો (Clock Out)',
    shiftActive: 'સક્રિય શિફ્ટ ચાલુ છે',
    shiftEnded: 'શિફ્ટ પૂર્ણ થઈ',
    shiftTimer: 'શિફ્ટનો સમયગાળો',
    standardShift: 'સામાન્ય શિફ્ટ: 8.0 કલાક',
    hoursWorked: 'કામ કરેલા કલાકો',
    overtimeHours: 'ઓવરટાઇમ કલાકો',
    worksiteLabel: 'કાર્યસ્થળ / કેમ્પસ',
    shiftHistory: 'હાજરી અને ઓવરટાઇમ ઇતિહાસ',
    noShiftsYet: 'આજના દિવસ માટે કોઈ શિફ્ટ નોંધાયેલી નથી.',
    shiftStartedSuccess: 'શિફ્ટ સફળતાપૂર્વક શરૂ થઈ સમય:',
    shiftEndedSuccess: 'શિફ્ટ પૂર્ણ થઈ. કુલ નોંધાયેલ સમય:',
    shiftAlreadyActiveError: 'તમારી એક શિફ્ટ પહેલેથી જ ચાલુ છે.',
    shiftNotStartedError: 'સમાપ્ત કરવા માટે કોઈ સક્રિય શિફ્ટ નથી. કૃપા કરીને પહેલા શિફ્ટ શરૂ કરો.',
    activeShiftBanner: 'તમે હાલમાં કાર્યસ્થળ પર સક્રિય ફરજ પર છો:',
    liveStatus: 'હાલમાં કાર્યરત',
    clockInTime: 'શરૂઆતનો સમય',

    wageTitle: 'વેતન પારદર્શિતા કેલ્ક્યુલેટર',
    wageSubtitle: 'નોંધાયેલા કલાકો અને ઓવરટાઇમ પર આધારિત પારદર્શક કમાણીનું અનુમાન',
    basicHourlyRate: 'મૂળભૂત કલાક દીઠ દર',
    regularHoursWorked: 'સામાન્ય કામના કલાકો',
    regularPay: 'મૂળભૂત પગાર',
    overtimeMultiplier: 'ઓવરટાઇમ ગુણક (દા.ત. 1.5x / 2.0x)',
    overtimePay: 'ઓવરટાઇમનું વધારાનું વળતર',
    statutoryDeductions: 'કાયદાકીય / કેન્ટીન કપાત',
    netEstimatedPay: 'અંદાજિત ચોખ્ખો પગાર (Take-home)',
    grossPay: 'કુલ અંદાજિત આવક',
    wageDisclaimerTitle: 'કાયદાકીય વેતન સૂચના',
    wageDisclaimerText:
      'આ ગણતરી નિયમો આધારિત અંદાજ છે. વાસ્તવિક ચુકવણી સરકારી લઘુત્તમ વેતન ધોરણો મુજબ કરવામાં આવે છે.',
    paySlipBreakdown: 'વિગતવાર પગાર પત્રક (Pay Slip)',
    inrCurrency: '₹',
    hourlyRateSuffix: '/ કલાક',

    safeVoiceTitle: 'સેફવોઇસ અનામી સુરક્ષા રિપોર્ટિંગ',
    safeVoiceSubtitle: 'ડર વિના જોખમી પરિસ્થિતિઓ અને સમસ્યાઓની જાણ કરો',
    safeVoiceShieldNotice: 'ઓળખ સુરક્ષા સક્રિય: તમારું નામ કે આઈડી સુપરવાઈઝરને ક્યારેય દેખાશે નહીં.',
    reportHazardBtn: 'અનામી જોખમ રિપોર્ટ દાખલ કરો',
    categoryLabel: 'જોખમનો પ્રકાર',
    workplaceLabel: 'કાર્યસ્થળ / વિભાગ',
    severityLabel: 'ગંભીરતાનું સ્તર',
    descriptionLabel: 'જોખમની વિગતવાર વિગત',
    descriptionPlaceholder:
      'વિગત આપો (દા.ત. સલામતી જાળી તૂટેલી છે, ખુલ્લો વીજળીનો વાયર છે, સાધનોનો અભાવ છે)...',
    submitReport: 'અનામી રિપોર્ટ સબમિટ કરો',
    reportSubmittedSuccess: 'સુરક્ષા રિપોર્ટ સફળતાપૂર્વક નોંધાયો! ટોકન:',
    yourAnonymousToken: 'તમારું અનામી રસીદ ટોકન',
    tokenInstruction: 'તમારી ઓળખ જાહેર કર્યા વગર સ્થિતિ તપાસવા માટે આ ટોકન સાચવી રાખો.',
    recentSubmittedReports: 'આ ઉપકરણ પરથી સબમિટ કરેલા રિપોર્ટ્સ',
    noReportsWorker: 'હજુ સુધી કોઈ રિપોર્ટ સબમિટ કરવામાં આવ્યો નથી.',
    privacyBoundaryNote: 'નોંધ: આ હેકાથોન પ્રોટોટાઇપ ઓળખની પૂર્ણ ગુપ્તતા સુનિશ્ચિત કરે છે.',

    fatigueTitle: 'થાક સુરક્ષા મોનિટર (FatigueGuard)',
    fatigueSubtitle: 'અકસ્માત અને અતિશય થાક નિવારણ માટે અગમચેતી ચેતવણી',
    fatigueLevel: 'હાલનું થાક જોખમ સ્તર',
    fatigueNormal: 'સામાન્ય / સુરક્ષિત કલાકો',
    fatigueCaution: 'સાવધાની સ્તર',
    fatigueWarning: 'ઉચ્ચ ઓવરટાઇમ ચેતવણી (>8 કલાક)',
    fatigueCritical: 'અત્યંત ગંભીર થાક જોખમ (>10 કલાક)',
    consecutiveHours: 'સતત ફરજના કલાકો',
    recommendedRest: 'ભલામણ કરેલ આરામનો સમય',
    ruleBasedDisclaimer:
      'નિયમ-આધારિત સુરક્ષા સૂચક: આ ચેતવણીઓ કાર્ય સમયના નિયમો પર આધારિત છે, તબીબી નિદાન નથી.',
    hydrationAlert: 'પાણી અને આરામની યાદ: ગરમીમાં દર 2 કલાકે 10 મિનિટ છાંયડામાં આરામ લો.',
    safeLimitBadge: 'શ્રમ ધોરણોના નિયમો મુજબ',

    passportTitle: 'ડિજિટલ સ્કિલ પાસપોર્ટ',
    passportSubtitle: 'ચકાસાયેલ સલામતી પ્રમાણપત્રો અને કાર્ય અનુભવનો રેકોર્ડ',
    workerIdLabel: 'કામદાર ઓળખ આઈડી',
    verifiedSkills: 'પ્રમાણિત ટેકનિકલ કુશળતા',
    trainingHours: 'સલામતી તાલીમના કલાકો',
    certificationsTitle: 'મળેલા સુરક્ષા પ્રમાણપત્રો',
    verifiedBadge: 'ચકાસાયેલ આપનાર',
    downloadCredential: 'પ્રમાણપત્ર કાર્ડ જુઓ',

    employerTitle: 'કાર્યબળ વ્યવસ્થાપન અને સુરક્ષા કમાન્ડ',
    employerSubtitle: 'શિફ્ટ પાલન, ન્યાયી ઓવરટાઇમ અને સ્થળ સુરક્ષાની વાસ્તવિક માહિતી',
    filterIndustry: 'ઉદ્યોગ ક્ષેત્ર પસંદ કરો',
    allIndustries: 'બધા ક્ષેત્રો (All Sectors)',
    industryConstruction: 'બાંધકામ સાઇટ્સ (Construction)',
    industryCampus: 'કોલેજ અને કેમ્પસ સુવિધાઓ (Campus)',
    kpiTotalWorkers: 'કુલ સક્રિય ડેમો કામદારો',
    kpiOnShift: 'હાલમાં શિફ્ટ પર હાજર',
    kpiOvertimeAlerts: 'ઓવરટાઇમ ચેતવણીઓ',
    kpiOpenHazards: 'બાકી સુરક્ષા રિપોર્ટ્સ',
    kpiFatigueWarnings: 'અતિશય થાક ચેતવણીઓ',
    comparisonTitle: 'ક્ષેત્રવાર સરખામણી: હાજરી અને ઓવરટાઇમ જોખમ',
    comparisonSubtitle: 'બાંધકામ સાઇટ વિરુદ્ધ કેમ્પસ સુવિધાઓનું તુલનાત્મક વિશ્લેષણ',
    workforceRosterTitle: 'લાઇવ શિફ્ટ હાજરી રોસ્ટર',
    incidentConsoleTitle: 'સેફવોઇસ ઘટના નિવારણ કન્સોલ (ઓળખ ગુપ્ત)',
    statusLabel: 'સ્થિતિ',
    actionUpdateStatus: 'ઘટનાની સ્થિતિ અપડેટ કરો',
    notesPlaceholder: 'સુપરવાઇઝર નિવારણ નોંધ ઉમેરો (દા.ત. રિપેરિંગ પૂર્ણ થયું)...',
    saveChanges: 'અપડેટ સાચવો',
    filterBySeverity: 'ગંભીરતા મુજબ ફિલ્ટર',
    noIncidentsFound: 'આ ફિલ્ટરમાં કોઈ ઘટના મળી નથી.',
    markedAsResolved: 'ઘટનાનું નિરાકરણ લાવવામાં આવ્યું છે.',
    statusOpen: 'ખુલ્લું (Open)',
    statusInProgress: 'ચાલુ છે (In Progress)',
    statusResolved: 'ઉકેલાયેલ (Resolved)',
    supervisorGuidance: 'સુપરવાઇઝર કાર્યવાહી: 2 કલાકની અંદર ગંભીર જોખમો તપાસો.',
  },
};
