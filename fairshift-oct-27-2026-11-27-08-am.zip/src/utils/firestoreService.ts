import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  SafetyReport,
  ShiftRecord,
  WorkerProfile,
  FatigueAlert,
  Industry,
} from '../types';
import { INITIAL_SHIFTS, INITIAL_SAFETY_REPORTS } from './storage';

const COLLECTIONS = {
  SHIFTS: 'shifts',
  SAFETY_REPORTS: 'safetyReports',
  FATIGUE_ALERTS: 'fatigueAlerts',
  WORKER_SKILLS: 'workerSkills',
  USERS: 'users',
  EMPLOYERS: 'employers',
};

// Seed initial demonstration data into Firestore if empty
export const seedInitialFirestoreDataIfEmpty = async () => {
  try {
    const snap = await getDocs(collection(db, COLLECTIONS.SHIFTS));
    if (snap.empty) {
      // Seed default shifts
      for (const shift of INITIAL_SHIFTS) {
        await setDoc(doc(db, COLLECTIONS.SHIFTS, shift.id), shift);
      }
    }

    const reportSnap = await getDocs(collection(db, COLLECTIONS.SAFETY_REPORTS));
    if (reportSnap.empty) {
      // Seed default safety reports
      for (const report of INITIAL_SAFETY_REPORTS) {
        await setDoc(doc(db, COLLECTIONS.SAFETY_REPORTS, report.id), report);
      }
    }
  } catch (err) {
    // If permission or network restriction, will operate with local memory fallback
    console.warn('Could not seed initial Firestore records (may require active auth):', err);
  }
};

/* ============================================================
   1. SHIFTS & ATTENDANCE (Cloud Firestore)
============================================================ */

export const subscribeWorkerShifts = (
  workerId: string,
  onUpdate: (shifts: ShiftRecord[]) => void,
  onError?: (err: any) => void
) => {
  const q = query(
    collection(db, COLLECTIONS.SHIFTS),
    where('workerId', '==', workerId)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const records: ShiftRecord[] = [];
      snapshot.forEach((docSnap) => {
        records.push(docSnap.data() as ShiftRecord);
      });
      // Sort newest first
      records.sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
      onUpdate(records);
    },
    (err) => {
      console.error('Shifts subscription error:', err);
      if (onError) onError(err);
      handleFirestoreError(err, OperationType.LIST, COLLECTIONS.SHIFTS);
    }
  );
};

export const subscribeAllShifts = (
  onUpdate: (shifts: ShiftRecord[]) => void,
  onError?: (err: any) => void
) => {
  return onSnapshot(
    collection(db, COLLECTIONS.SHIFTS),
    (snapshot) => {
      const records: ShiftRecord[] = [];
      snapshot.forEach((docSnap) => {
        records.push(docSnap.data() as ShiftRecord);
      });
      records.sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime());
      onUpdate(records);
    },
    (err) => {
      console.error('All shifts subscription error:', err);
      if (onError) onError(err);
      handleFirestoreError(err, OperationType.LIST, COLLECTIONS.SHIFTS);
    }
  );
};

export const createShiftRecord = async (shift: ShiftRecord): Promise<void> => {
  try {
    await setDoc(doc(db, COLLECTIONS.SHIFTS, shift.id), shift);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${COLLECTIONS.SHIFTS}/${shift.id}`);
  }
};

export const updateShiftRecord = async (shiftId: string, partial: Partial<ShiftRecord>): Promise<void> => {
  try {
    await updateDoc(doc(db, COLLECTIONS.SHIFTS, shiftId), partial);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${COLLECTIONS.SHIFTS}/${shiftId}`);
  }
};

/* ============================================================
   2. SAFEVOICE HAZARD REPORTS (Cloud Firestore)
============================================================ */

export const subscribeSafetyReports = (
  onUpdate: (reports: SafetyReport[]) => void,
  onError?: (err: any) => void
) => {
  return onSnapshot(
    collection(db, COLLECTIONS.SAFETY_REPORTS),
    (snapshot) => {
      const records: SafetyReport[] = [];
      snapshot.forEach((docSnap) => {
        records.push(docSnap.data() as SafetyReport);
      });
      records.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      onUpdate(records);
    },
    (err) => {
      console.error('Safety reports subscription error:', err);
      if (onError) onError(err);
      handleFirestoreError(err, OperationType.LIST, COLLECTIONS.SAFETY_REPORTS);
    }
  );
};

export const submitSafetyReport = async (report: SafetyReport): Promise<void> => {
  try {
    await setDoc(doc(db, COLLECTIONS.SAFETY_REPORTS, report.id), report);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${COLLECTIONS.SAFETY_REPORTS}/${report.id}`);
  }
};

export const updateSafetyReportStatus = async (
  reportId: string,
  status: SafetyReport['status'],
  adminNotes?: string
): Promise<void> => {
  try {
    const payload: Partial<SafetyReport> = {
      status,
      adminNotes: adminNotes ?? '',
      ...(status === 'Resolved' ? { resolvedAt: new Date().toISOString() } : {}),
    };
    await updateDoc(doc(db, COLLECTIONS.SAFETY_REPORTS, reportId), payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `${COLLECTIONS.SAFETY_REPORTS}/${reportId}`);
  }
};

/* ============================================================
   3. FATIGUE ALERTS (Cloud Firestore)
============================================================ */

export const recordFatigueAlert = async (alert: FatigueAlert): Promise<void> => {
  try {
    await setDoc(doc(db, COLLECTIONS.FATIGUE_ALERTS, alert.id), {
      ...alert,
      createdAt: new Date().toISOString(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `${COLLECTIONS.FATIGUE_ALERTS}/${alert.id}`);
  }
};

export const subscribeWorkerFatigueAlerts = (
  workerId: string,
  onUpdate: (alerts: FatigueAlert[]) => void
) => {
  const q = query(
    collection(db, COLLECTIONS.FATIGUE_ALERTS),
    where('workerId', '==', workerId)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const records: FatigueAlert[] = [];
      snapshot.forEach((docSnap) => {
        records.push(docSnap.data() as FatigueAlert);
      });
      onUpdate(records);
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, COLLECTIONS.FATIGUE_ALERTS);
    }
  );
};
